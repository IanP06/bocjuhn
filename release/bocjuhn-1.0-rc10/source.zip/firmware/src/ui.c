/* SPDX-License-Identifier: GPL-3.0-only
 * TONITOR: the panel and the screen.
 *
 *   FX SEL ENV LFO EDIT GLO   the top row: layers 1 to 6 (its light: the layer chosen)
 *   PRESETS (knob)            the layer's engine: FM, ANIMA
 *   HOME                      a new sound for the layer, on its engine
 *   OCT- / OCT+               the layer's octave, -3 .. +3 (their lights: below or above the middle)
 *   the white keys            play the layer chosen, in the scale chosen: the first key is the root, every
 *                             white key the next note of the scale, up across the keyboard. Two voices: a note
 *                             never cuts the release of the one before. A key lifted ends its note on the layer
 *                             it was played on, so a held note goes on sounding while another is played.
 *                             (The black keys play no notes: kept for other things.)
 *   ARP                       the SCALE page (its light: on it): SELECT the scale, ALGORITHM the root
 *   REC                       the layer's looper: arm a new loop (the first note starts it), end it (it
 *                             plays, over the layer's other loops, each in its own length): up to 10 loops
 *   REC held                  empty the layer's looper (all its loops)
 *   PLAY                      stop the layer's loops, or play them again
 *   SELECT (knob)             the layer's level, OFF and -28.5 .. +4.5 dB in steps of 1.5 dB
 *   ALGORITHM (knob)          the layer's pan, left to right in 41 steps
 *   KNOB 1                    the layer's DJ filter: left a resonant low-pass, right a high-pass, the middle
 *                             off; while it turns (and a second after) the whole screen is its dial
 *   KNOB 2                    the layer's granulator: the middle off; left dark, long, smeared grains; right
 *                             short, fast, scattered, jittered ones (gran.c); its dial over the screen
 *   KNOB 3                    the layer's crush: the middle off; left fewer bits, right a lower sample rate;
 *                             its dial over the screen
 *   KNOB 4                    the layer's send to the master reverb, 0 .. 100; its dial over the screen
 *   SEQ                       the REVERB page (its light: on it); there KNOB 1..4 are SIZE, DECAY, DAMP and
 *                             MIX. SEQ again, or a layer's button, goes back
 *   SAVE                      the SNAPSHOTS page (snaps.c; again: back): the session's 16 states on the white
 *                             keys. A key let go soon: its snapshot recalled; held 0.8 s: the state now stored in
 *                             it; SHIFT held too: emptied. PRESETS moves the frame, SAVE held stores into it. KNOB 1:
 *                             the morph time, 0 .. 30 s
 *   SAVE held                 save: over the session loaded (or last saved) at once; else a new session,
 *                             numbered after the last, asked first (PRESETS: NO / YES, SAVE to answer)
 *   SHIFT + SAVE              the SESSIONS page (again: back): PRESETS chooses a session, SAVE loads it and goes
 *                             back. Held 0.8 s: GLOBAL SETUP
 *   USB MIDI notes            as the keys
 *   MASTER (knob)             the level
 *
 * The screen is for low vision: a few words, very large, high contrast, each layer its own colour --
 * the layer's number, its engine, its sound; a short message in black on white when something changes;
 * the looper's state over the sound, red: ARMED flashing, REC steady; a looper emptied flashes the whole
 * screen. Down the left, the layer's level meter: what it sounds, in its colour, and a white bar across it
 * at the level the SELECT knob sets. Along the bottom, its pan: a block in its colour on a track from L to
 * R, a tick at the middle. KNOB 1 to 4 (filter, grain, crush, reverb send) show, while they turn and a second
 * after, a dial over the whole screen: the same for the three. Turning the other knobs says the value in the
 * message band. The REVERB page shows its four values in rows,
 * each with a bar; the one just turned in black on white. Saving, loading, emptying a looper flash the
 * whole screen. The SESSIONS page shows the session chosen as a very large number. */

/* the panel: which matrix button carries which printed label (as SLOOP's panel.c, default table) */
enum { B_FX, B_SEL, B_ENV, B_LFO, B_EDIT, B_GLO, B_HOME, B_SAVE, B_ARP, B_SEQ, B_PLAY, B_REC, B_OCTDN, B_OCTUP, NB };
enum { EN_SELECT, EN_ALGO, EN_PRESET, EN_K1, EN_K2, EN_K3, EN_K4, NE };
static const uint8_t PANEL_BTN[NB] = {2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 0, 1};
static const uint8_t PANEL_ENC[NE] = {0, 1, 6, 2, 3, 4, 5};
static const uint8_t LAYER_BTN[NLAYER] = {B_FX, B_SEL, B_ENV, B_LFO, B_EDIT, B_GLO};
#define NKEY 27u
#define KEY_SHIFT 25u            /* the rightmost black key: pressed, the keys held latch; held, a latched key lets go */
#define KEY_NONE 0xFFu
#define KEY_AMB 1u               /* the leftmost black key: the AMBIENT path (again: back to the open path); SHIFT +:
                                  * a scale and root drawn at random */
#define KEY_EXP 3u               /* the second: the EXPERIMENTAL path */
#define KEY_ENV 20u              /* the 3rd black key from the right: the ENVELOPE page, up and down (SHIFT: the
                                 * sound's own envelope again) */
#define KEY_EDIT 22u             /* the black key before SHIFT: EDIT, on and off (KNOB 1 .. 4: the sound's macros) */
#define KEY_CHORD 5u             /* the 3rd black key: held 0.6 s, the track's chord mode on or off; pressed, the next
                                  * chord form */
#define KEY_REV 8u               /* the 4th black key: the chosen track's loops backwards (again: forwards) */
#define KEY_PEND 10u             /* the 5th: PENDULUM, forwards and backwards in turn */
#define KEY_RAND 13u             /* the 6th: RANDOM, forwards from a note drawn at random each time the next is due */
#define KEY_HALF 15u             /* the 7th: half speed (again: normal) */
#define KEY_DOUBLE 17u           /* the 8th: double speed */
#define KEY_NOTE0 53             /* the lowest key, F3 */

/* Engine identity follows the sound across tracks, pages and dials. */
static const uint16_t ENGINE_COL[NENG] = {
    RGB(51,123,255), RGB(0,255,72), RGB(0,234,255), RGB(255,37,218),
    RGB(180,255,0), RGB(255,48,72), RGB(255,230,0), RGB(255,112,0)
};

static struct {
    uint8_t sel;
    uint8_t engine[NLAYER];
    int8_t oct[NLAYER];
    uint8_t key_layer[NKEY], key_note[NKEY];   /* what a key down holds (KEY_NONE: nothing, it latched or let go) */
    uint8_t path[NLAYER];        /* each layer's generative path (PATH_*): HOME draws on it */
    uint8_t edit;                /* EDIT on: KNOB 1 .. 4 turn the chosen layer's sound's macros */
    uint8_t play_down, ovd;      /* PLAY down (since play_t0); held: the overdubs on the white keys */
    uint32_t play_t0;
    int32_t shown_ovd;
    int8_t mac[NLAYER][NENG][NMAC];   /* the macros on each layer's sound of each engine (0: as drawn) */
    uint32_t latch[NLAYER];      /* the keys latched on each layer (lit while it is chosen) */
    uint8_t latch_note[NLAYER][NKEY];
    uint8_t midi_mask[128];      /* each MIDI note held: the tracks it plays on (a bit each; setup.c) */
    uint32_t keys;               /* the keys down last time */
    char msg[16];
    uint32_t msg_until;
    uint32_t home_until;         /* HOME's light after a new sound */
    uint32_t seed;
    uint32_t rec_t0;             /* REC pressed at; held 1 s: the looper emptied */
    uint8_t rec_down, rec_done;
    uint32_t flash_t0;           /* the screen flashes from then (a looper emptied, a session saved / loaded) */
    uint8_t flash_on, flash_phase;
    uint16_t flash_col;
    char flash_l1[12], flash_l2[12];
    uint8_t sc_page;             /* the SCALE page is up */
    uint8_t sc_peek;             /* .. or shown a moment, until sc_peek_until (SHIFT + black key 1: a new scale) */
    uint32_t sc_peek_until;
    uint8_t scale, root;         /* the keyboard's scale (SCALES) and root (0 = C .. 11 = B) */
    int8_t lx;                   /* the loops' transposition, in steps of the scale (SHIFT + OCT) */
    int8_t lxt[NLAYER];          /* each track's own, on top (SHIFT + its button held + OCT) */
    uint8_t chord_on[NLAYER], chord_form[NLAYER];   /* each track's chord mode, and its form (CH_*) */
    uint8_t key_form[NKEY];      /* a key down: the chord it holds (form + 1; 0: a note) */
    uint8_t latch_form[NLAYER][NKEY];   /* .. a latched key's */
    uint8_t cho_down, cho_done;  /* the chord key down since cho_t0; held long enough: done */
    uint8_t edit_down, edit_done;   /* EDIT down since edit_t0 (let go soon: EDIT; held: the balls' page) */
    uint32_t edit_t0;
    uint8_t bb_page;             /* the chosen track's balls' page is up (it closes as the other pages do) */
    uint8_t vary_shown;
    uint8_t clock_page, clock_target, acid_page;
    uint8_t kit_page, kit_pad;
    uint8_t filter_page, gr_page, speed_page, speed_loop; /* INTERVAL: continuous loop clocks */
    uint8_t bl_page;             /* the chosen track's BRICKLAYER page is up (closes as the other pages do) */
    uint8_t env_down, env_done;  /* the envelope key down since env_t0 (let go soon: ENVELOPE; held: BRICKLAYER's page) */
    uint32_t env_t0;
    uint8_t blrec_down, blrec_done;   /* REC down on BRICKLAYER's page since blrec_t0 (held 1 s: emptied) */
    uint32_t blrec_t0;          /* (VARY just set: what the screen shows until the ISR has taken it, + 1) */
    uint32_t cho_t0;
    int8_t sc_touched;           /* 0 the root just turned, 1 the scale, -1 none (until sc_touch_until) */
    uint32_t sc_touch_until;
    int8_t shown_sc_touch;
    uint8_t shown_scale, shown_root;
    uint8_t ses_page;            /* 0 none, SP_LIST the sessions, SP_ASK the question before a save */
    uint8_t ses_ix;              /* the slot shown on the SESSIONS page, 1 .. 64 */
    uint8_t ses_yes;             /* the question's answer */
    uint16_t ses_new;            /* the number it asks about */
    uint8_t ses_over;            /* .. and it holds a session: the question is OVERWRITE */
    uint8_t snap_page, snap_ix;  /* the SNAPSHOTS page; its frame (0 .. 15) */
    int8_t snap_key;             /* the white key down on it (its snapshot, -1 none), since snap_t0; held: done */
    uint8_t snap_done, snap_sh;
    uint32_t snap_t0;
    uint8_t morph;               /* KNOB 1 there: the morph time, half seconds (0: at once) */
    uint32_t morph_until;        /* .. its dial shown until then */
    int32_t shown_snap, shown_morph;
    uint32_t ssv_t0;             /* SHIFT + SAVE pressed at: held 0.8 s is GLOBAL SETUP, shorter the SESSIONS page */
    uint8_t ssv_down, ssv_long;
    uint8_t set_page;            /* GLOBAL SETUP up (setup.c) */
    uint8_t mod_page, mod_ix;    /* the MOD page up (SEQ's third); its entry: LFO 1, LFO 2, MOD A .. D */
    uint8_t rx_page;             /* the PLAY ALONG page up (SEQ's fourth: REACT, SHADOW, ARPEGGIO; react.c) */
    int8_t mod_touched;          /* (the row just turned, until mod_touch_until) */
    uint32_t mod_touch_until, mod_drawn_at;
    int32_t shown_top;           /* (the track view's top corners as drawn: the octave, the battery, VAR) */
    uint8_t pre_page;            /* 0 none, SP_LIST the presets of pre_eng, SP_ASK the question before saving over one */
    uint8_t pre_eng;             /* the engine whose presets they are (the layer's, as SHIFT and SAVE opened them) */
    uint8_t pre_ix;              /* the slot chosen, 1 .. 64 */
    uint8_t pre_yes;
    int16_t shown_pre;           /* (what the page shows: slot, question and answer) */
    uint32_t save_t0;            /* SAVE pressed at: held 0.8 s is a save, shorter a press */
    uint8_t save_down, save_long;
    uint32_t arp_t0;             /* ARP pressed at, on the PRESETS page: held 0.8 s saves, shorter loads */
    uint8_t arp_down, arp_long;
    uint8_t trk_down, trk_done;  /* a track's button held (its number + 1) since trk_t0: copy, or paste */
    uint32_t trk_t0;
    int8_t shown_ses;            /* (the page as last drawn) */
    int16_t shown_ses_ix;
    /* the screen: what each band shows, as last drawn */
    int32_t shown_sel, shown_eng, shown_msg;
    char shown_text[16];
    int8_t level[NLAYER];        /* 0 = off, 1..LEVEL_MAX: 1.5 dB steps, LEVEL_UNITY = 0 dB */
    int8_t pan[NLAYER];          /* -PAN_MAX (left) .. PAN_MAX (right) */
    int8_t send[NLAYER];         /* 0 .. 100: to the reverb */
    int8_t flt[NLAYER];          /* the DJ filter, -FLT_MAX .. FLT_MAX, 0 off */
    int8_t gr[NLAYER];           /* the granulator, -FLT_MAX .. FLT_MAX, 0 off */
    int8_t cr[NLAYER];           /* the crush, -FLT_MAX .. FLT_MAX, 0 off */
    uint8_t dial;                /* the dial over the screen: DIAL_FLT, DIAL_GR, DIAL_SEND */
    uint32_t dial_until, dial_drawn_at;   /* it shows until then; when it was last drawn */
    int16_t shown_dial;          /* (the value last drawn, + the kind x 256) */
    int8_t rvp[4];               /* the reverb: SIZE DECAY DAMP MIX, 0 .. 100 */
    int8_t dlp[4];               /* the delay: TIME REPEATS (the feedback) DAMP MIX, 0 .. 100 */
    int8_t dsend[NLAYER];        /* each track's send to the delay, 0 .. 100 (SHIFT + KNOB 4) */
    int8_t dist[NLAYER];         /* each track's distortion, 0 .. 100, 0 off (SHIFT + KNOB 3) */
    uint8_t rv_page;             /* the REVERB page is up -- or the DELAY page, fx 1 (SEQ; SHIFT + SEQ) */
    uint8_t fx;
    int8_t rv_touched;           /* the row just turned (-1 none), until rv_touch_until */
    uint32_t rv_touch_until;
    int8_t shown_rvp[4], shown_touch;
    uint8_t shown_page;
    uint8_t env_page;            /* the ENVELOPE page is up: KNOB 1 .. 4, the track's own A D S R */
    int8_t env[NLAYER][NENG][4]; /* each track's own envelope on each engine's sound, 0 .. 100 (layers.c env_ms) */
    uint8_t env_on[NLAYER][NENG];   /* .. in use (0: the sound's own envelope, as drawn) */
    int8_t env_nat[4];           /* the sound's own, read as A D S R (env_nat_ok: still the sound shown) */
    uint8_t env_nat_ok;
    int8_t env_touched;          /* the value just turned (-1 none), until env_touch_until */
    uint32_t env_touch_until;
    int8_t shown_env[4], shown_env_touch;
    uint8_t shown_env_on;
    int32_t shown_meter, shown_level, shown_pan, shown_msel;
    uint32_t meter_at;
    uint8_t force;
} ui;

static uint16_t ui_color(uint32_t l) { return ENGINE_COL[ui.engine[l] % NENG]; }

/* ------------------------------------------------------------ notes --- */
static uint8_t press_vel;                /* the level of the notes pressed now, 1 .. 126 (0: full) -- the balls set it */
static uint8_t press_seq;                /* the notes pressed now are a sequencer's: the looper does not record them */
static void rx_hear(uint32_t note, uint32_t vel, int on);   /* (REACT listens to the guide: react.c) */
static void note_press(uint32_t l, uint32_t note)
{
    if (l == rx_ear)
        rx_hear(note, press_vel, 1);
    ev_post(EV_ON, l, note, press_vel | (press_seq ? EV_UNHEARD : 0u));
}
static void note_release(uint32_t l, uint32_t note)
{
    if (l == rx_ear)
        rx_hear(note, 0, 0);
    ev_post(EV_OFF, l, note, press_seq ? EV_UNHEARD : 0u);
}

static void ui_draw(void);
static void say(const char *s, uint32_t ms)
{
    str_cpy(ui.msg, s, sizeof ui.msg);
    ui.msg_until = fm1_ms + ms;
}

/* (LEVEL_MAX, LEVEL_UNITY, PAN_MAX: layers.c, the modulation's too) */
static const int8_t PAN_DEF[NLAYER] = {0, 10, -5, 5, -2, 2};   /* (track 1 in the middle) */
#define SEND_DEF 40
enum { DIAL_FLT, DIAL_GR, DIAL_SEND, DIAL_CR, DIAL_DSEND, DIAL_DIST, DIAL_MAC };   /* the knobs whose dial covers the screen (DIAL_MAC + j: EDIT's j) */

/* the scales: the white keys play their degrees, from the root, up */
#define NSCALE 23                /* (new ones at the end: sessions keep the number) */
#define SCALE_MAXN 8
/* (a long name split over the two lines rather than squeezed past reading: host.c flows checks) */
static const char *const SCALE_L1[NSCALE] = {"MAJOR", "MINOR", "MINOR", "MINOR", "DORIAN", "MINOR", "WHOLE", "ENIGMATIC", "JAPANESE",
    "PHRYGIAN", "LYDIAN", "MIXO-", "LOCRIAN", "MAJOR", "BLUES", "HUNGAR-", "DOUBLE", "PHRYGIAN", "JAPANESE",
    "JAPANESE", "PELOG", "OCTA-", "PROME-"};
static const char *const SCALE_L2[NSCALE] = {"", "NATURAL", "HARMONIC", "MELODIC", "", "PENTA", "TONE", "", "IN",
    "", "", "LYDIAN", "", "PENTA", "", "IAN MINOR", "HARMONIC", "DOMINANT", "HIRAJOSHI", "IWATO", "", "TONIC", "THEUS"};
static const uint8_t SCALE_N[NSCALE] = {7, 7, 7, 7, 7, 5, 6, 7, 5, 7, 7, 7, 7, 5, 6, 7, 7, 7, 5, 5, 5, 8, 6};
static const uint8_t SCALE_STEP[NSCALE][SCALE_MAXN] = {
    {0, 2, 4, 5, 7, 9, 11},      /* major */
    {0, 2, 3, 5, 7, 8, 10},      /* natural minor */
    {0, 2, 3, 5, 7, 8, 11},      /* harmonic minor */
    {0, 2, 3, 5, 7, 9, 11},      /* melodic minor (rising) */
    {0, 2, 3, 5, 7, 9, 10},      /* dorian */
    {0, 3, 5, 7, 10},            /* minor pentatonic */
    {0, 2, 4, 6, 8, 10},         /* whole tone */
    {0, 1, 4, 6, 8, 10, 11},     /* enigmatic (Verdi's scala enigmatica) */
    {0, 1, 5, 7, 8},             /* in (miyako-bushi): Japan's sorrowful scale, koto and shakuhachi */
    {0, 1, 3, 5, 7, 8, 10},      /* phrygian */
    {0, 2, 4, 6, 7, 9, 11},      /* lydian */
    {0, 2, 4, 5, 7, 9, 10},      /* mixolydian */
    {0, 1, 3, 5, 6, 8, 10},      /* locrian */
    {0, 2, 4, 7, 9},             /* major pentatonic */
    {0, 3, 5, 6, 7, 10},         /* blues (the minor pentatonic and the flat fifth) */
    {0, 2, 3, 6, 7, 8, 11},      /* hungarian minor */
    {0, 1, 4, 5, 7, 8, 11},      /* double harmonic (byzantine) */
    {0, 1, 4, 5, 7, 8, 10},      /* phrygian dominant (the harmonic minor's fifth mode) */
    {0, 2, 3, 7, 8},             /* hirajoshi */
    {0, 1, 5, 6, 10},            /* iwato */
    {0, 1, 3, 7, 8},             /* pelog (selisir), in equal temperament */
    {0, 1, 3, 4, 6, 7, 9, 10},   /* octatonic, half step first (diminished) */
    {0, 2, 4, 6, 9, 10},         /* prometheus (Scriabin's mystic chord as a scale) */
};
static const char *const NOTE_NAME[12] = {"C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B"};
#define SCALE_BASE 48            /* the root's octave: C3 .. B3 on the first key (the layer's octave moves it) */

/* white key k's place among the white keys (0 .. 15), -1 for a black key (keys from F3, chromatic) */
static int32_t white_ix(uint32_t k)
{
    static const int8_t W[12] = {0, -1, 1, -1, 2, 3, -1, 4, -1, 5, -1, 6};   /* C .. B: whites in an octave */
    uint32_t n = 53u + k, o = n / 12u;
    int32_t w = W[n % 12u];
    if (w < 0)
        return -1;
    return (int32_t)o * 7 + w - (4 * 7 + 3);                                  /* F3 = 0 */
}
/* the note white key w plays, in the scale, on a layer at octave oct */
static uint32_t scale_note(int32_t w, int32_t oct)
{
    int32_t n = SCALE_N[ui.scale], q = w >= 0 ? w / n : -((n - 1 - w) / n);   /* (below the root too: a step moved) */
    return (uint32_t)clampi(SCALE_BASE + ui.root + 12 * oct + 12 * q + SCALE_STEP[ui.scale][w - q * n], 12, 120);
}
/* the loops' transposition and the scale it walks, to the ISR (which moves the notes sounding) */
static void lx_post(void)
{
    uint32_t k, m = 0;
    for (k = 0; k < SCALE_N[ui.scale]; k++)
        m |= 1u << ((ui.root + SCALE_STEP[ui.scale][k]) % 12u);
    lx_want_mask = (uint16_t)m;
    lx_want_steps = ui.lx;
    for (k = 0; k < NLAYER; k++)
        lx_want_tr[k] = ui.lxt[k];
    RING_PUBLISH();
    ev_post(EV_LOOP_XP, 0, 0, 0);
}
/* the scale's pitch classes, as a mask from C */
static uint32_t scale_mask(void)
{
    uint32_t k, m = 0;
    for (k = 0; k < SCALE_N[ui.scale]; k++)
        m |= 1u << ((ui.root + SCALE_STEP[ui.scale][k]) % 12u);
    return m;
}
/* the chord forms: three notes, as steps of the scale from the key's note (so in the scale, their quality as the
 * scale gives it) */
#define CH_N 7u
static const int8_t CH_STEP[CH_N][3] = {{0, 2, 4}, {2, 4, 7}, {-3, 0, 2}, {0, 1, 4}, {0, 3, 4}, {0, 4, 9}, {0, 3, 6}};
static const char *const CH_NAME[CH_N] = {"TRIAD", "INV 1", "INV 2", "SUS2", "SUS4", "OPEN", "FOURTHS"};
static void chord_notes(uint32_t root, uint32_t form, uint32_t *n)
{
    uint32_t i, m = scale_mask();
    for (i = 0; i < 3u; i++)
        n[i] = lx_map(root, CH_STEP[form % CH_N][i], m);
}
/* a note, or a chord (form + 1), struck or let go on track l */
static void chord_press(uint32_t l, uint32_t root, uint32_t f1, int on)
{
    if(ui.engine[l]==ENG_BAY)f1=0;
    uint32_t n[3], i;
    if (!f1) {
        if (on)
            note_press(l, root);
        else
            note_release(l, root);
        return;
    }
    chord_notes(root, f1 - 1u, n);
    for (i = 0; i < 3u; i++)
        if (on)
            note_press(l, n[i]);
        else
            note_release(l, n[i]);
}
/* a note (or chord) latched on track l: told to the voices, so the overload guard never lets it go */
static void latch_mark(uint32_t l, uint32_t root, uint32_t f1)
{
    if(ui.engine[l]==ENG_BAY)f1=0;
    uint32_t n[3], i;
    if (!f1) {
        ev_post(EV_LATCH, l, root, 1);
        return;
    }
    chord_notes(root, f1 - 1u, n);
    for (i = 0; i < 3u; i++)
        ev_post(EV_LATCH, l, n[i], 1);
}
/* a note (or chord) of BALLSY's or BRICKLAYER's: played as a key's, but not for the looper (it records the keys) */
static void seq_press(uint32_t l, uint32_t root, uint32_t f1, int on)
{
    press_seq = 1;
    chord_press(l, root, f1, on);
    press_seq = 0;
}
#include "react.c"                       /* (REACT, SHADOW, ARPEGGIO: the PLAY ALONG page, SEQ's fourth) */
/* the PLAY ALONG page is what the screen shows (no other page over it) */
static int rx_page_up(void)
{
    return ui.rx_page && !ui.rv_page && !ui.ses_page && !ui.snap_page && !ui.sc_page && !ui.pre_page && !ui.set_page && !ui.env_page &&
           !ui.bb_page && !ui.bl_page && !ui.mod_page;
}
static uint8_t rx_focus;                         /* (the page: the knob turned last) */
/* track l's latched notes (and chords) moved by d steps of the scale, as its loops are */
static void latch_move(uint32_t l, int32_t d)
{
    uint32_t k, m = scale_mask();
    if (!d)
        return;
    uint32_t latch = 0;
    uint8_t note[NKEY], form[NKEY];
    for (k = 0; k < NKEY; k++)
        if ((ui.latch[l] >> k) & 1u) {
            uint32_t was = ui.latch_note[l][k], now = lx_map(was, d, m), k2;
            chord_press(l, was, ui.latch_form[l][k], 0);
            chord_press(l, now, ui.latch_form[l][k], 1);
            latch_mark(l, now, ui.latch_form[l][k]);
            /* the key lit moves as the hand would: d white keys along, unless that is off the keyboard or taken */
            for (k2 = 0; k2 < NKEY && white_ix(k2) != white_ix((uint32_t)k) + d; k2++)
                ;
            if (k2 == NKEY || ((latch >> k2) & 1u))
                k2 = k;
            if ((latch >> k2) & 1u)
                for (k2 = 0; k2 < NKEY && (white_ix(k2) < 0 || ((latch >> k2) & 1u) || ((ui.latch[l] >> k2) & 1u && k2 != k)); k2++)
                    ;                            /* (a free white key, should two meet at an edge) */
            if (k2 < NKEY) {
                latch |= 1u << k2;
                note[k2] = (uint8_t)now;
                form[k2] = ui.latch_form[l][k];
            }
        }
    for (k = 0; k < NKEY; k++)
        if ((latch >> k) & 1u) {
            ui.latch_note[l][k] = note[k];
            ui.latch_form[l][k] = form[k];
        } else
            ui.latch_form[l][k] = 0;
    ui.latch[l] = latch;
}

static void seq_clock(uint32_t l,uint32_t target,uint32_t root,uint32_t form,uint32_t vel,uint32_t due,uint32_t length) {
    uint32_t notes[3]={root,0,0},n=1;
    if(form && ui.engine[l]!=ENG_ANIMA && ui.engine[l]!=ENG_BAY) {chord_notes(root,form-1,notes);n=3;}
    for(uint32_t i=0;i<n;i++) clock_post(l,target,notes[i],vel,due,length);
}
#include "balls.c"                       /* (BALLSY, the physics sequencer: SHIFT + EDIT) */
#include "bricks.c"                      /* (BRICKLAYER, the step sequencer: SHIFT + the envelope key) */
/* PLAY is the sequencer's on its page (BALLSY's or BRICKLAYER's, up), the looper's on every other */
static int seq_on(uint32_t l) { return bl.on[l] || bb.on[l]; }
static int seq_page(void) { return (ui.clock_page && ((ui.clock_target==CK_BALL && bb.on[ui.sel]) || (ui.clock_target==CK_BRICK && bl.on[ui.sel]))) || (ui.bl_page && bl.on[ui.sel]) || (ui.bb_page && bb.on[ui.sel]); }
static const int8_t RV_DEF[4] = {70, 65, 40, 50};      /* lush, present, not overdone */
static const char *const RV_NAME[4] = {"SIZE", "DECAY", "DAMP", "MIX"};
static const int8_t DL_DEF[4] = {65, 40, 40, 50};      /* 400 ms, a few repeats, a little darker each */
static const char *const DL_NAME[4] = {"TIME", "REPEATS", "DAMP", "MIX"};   /* (REPEATS: the feedback) */

/* a level (in 1/256 of a step) as the ISR's gain, Q14: 1.5 dB a step, log2 of the gain = (lv - unity) x 1.5 / 6.0206 */
static int32_t level_gain(int32_t lv_q8)
{
    int32_t db16 = ((lv_q8 - LEVEL_UNITY * 256) * 16328) >> 8;   /* x 0.24914, Q16 */
    return lv_q8 <= 0 ? 0 : (int32_t)(exp2_q16(db16) >> 2);
}
/* the layer's level and pan, to the ISR */
static void level_pan_apply(uint32_t l)
{
    int32_t ph;
    lay_gain[l] = level_gain(ui.level[l] * 256);
    ph = (int32_t)((uint32_t)(ui.pan[l] + PAN_MAX) * (0x40000000u / (2u * PAN_MAX)));   /* 0 .. a quarter turn */
    lay_pl[l] = sin_ph((uint32_t)ph + 0x40000000u);
    lay_pr[l] = sin_ph((uint32_t)ph);
    lay_send[l] = ui.send[l] * 32767 / 100;
    lay_dsend[l] = ui.dsend[l] * 32767 / 100;
    lay_dist[l] = ui.dist[l];
    lay_lvl[l] = ui.level[l];
    lay_pan[l] = ui.pan[l];
    lay_flt[l] = ui.flt[l];
    lay_gr[l] = ui.gr[l];
    lay_cr[l] = ui.cr[l];
}

enum { SP_LIST = 1, SP_ASK = 2 };
#define C_SES ui_color(ui.sel)
#define C_SNAP ui_color(ui.sel)
#define C_FULL C_RED
#define C_OK C_GREEN
#define C_BAD C_RED

/* the whole screen flashes: l1 over l2 (a number in very large type), in colour c and black by turns */
static void flash(const char *l1, const char *l2, uint16_t c)
{
    str_cpy(ui.flash_l1, l1, sizeof ui.flash_l1);
    str_cpy(ui.flash_l2, l2, sizeof ui.flash_l2);
    ui.flash_col = c;
    ui.flash_t0 = fm1_ms;
    ui.flash_on = 1;
    ui.flash_phase = 0xFF;
}

/* sessions.c (after this file) */
static int ses_save(uint32_t num);
static int ses_load(uint32_t i);
static uint32_t ses_next_number(void);
static int ses_has(uint32_t num);
static int ses_current(void);
static void ses_choose(uint32_t num);
static void ses_fresh(uint32_t num);
static void clip_copy(uint32_t l);
static void clip_paste(uint32_t l);
static int clip_from(void);                  /* the track on the clipboard, -1 if it is empty */
static int ses_load_slot(uint32_t num);
/* snaps.c (after this file) */
#define NSNAP 16u                /* a session's snapshots */
#define MORPH_STEPS 60u          /* the morph time: 0 .. 60 half seconds */
static int snap_store(uint32_t i);
static void snap_loop_emptied(uint32_t l);
static void snap_recall(uint32_t i, uint32_t morph_half_s);
static void snap_clear(uint32_t i);
static int snap_has(uint32_t i);
static int snap_current(void);
static int snap_morph_target(void);
static void morph_poll(void);
static void mac_apply(uint32_t l);
static int pre_kind(uint32_t e, uint32_t slot);   /* the kind of sound in engine e's slot, -1 if none */
static int pre_save(uint32_t l, uint32_t e, uint32_t slot);
static int pre_load(uint32_t l, uint32_t e, uint32_t slot);
#define PRE_SLOTS 64u
#define SES_SLOTS 64u
enum { SES_OK, SES_NOFLASH, SES_FULL, SES_FAIL };

static void ses_done(int rc, const char *what, uint32_t num)
{
    char n[8];
    fmt_int(n, (int32_t)num);
    if (rc == SES_OK)
        flash(what, n, C_OK);
    else
        flash(rc == SES_FULL ? "FULL" : rc == SES_NOFLASH ? "NO FLASH" : "FAILED", "", C_BAD);
    ui.force = 1;
}
/* the presets page: SAVE held saves the layer's sound into the slot chosen (asked first over a full one) */
static void pre_done(int rc, const char *what)
{
    ses_done(rc, what, ui.pre_ix);               /* the whole screen: SAVED / LOADED and the slot, very large */
}
static void pre_long(void)
{
    if (ui.pre_page == SP_ASK)
        return;
    if (pre_kind(ui.pre_eng, ui.pre_ix) >= 0) {
        ui.pre_page = SP_ASK;
        ui.pre_yes = 0;                          /* (over a sound: NO until turned to YES) */
        ui.force = 1;
        return;
    }
    pre_done(pre_save(ui.sel, ui.pre_eng, ui.pre_ix), "SAVED");
}
/* .. SAVE pressed: the slot chosen loaded into the layer (and back to playing), or the question answered */
static void pre_short(void)
{
    if (ui.pre_page == SP_ASK) {
        ui.pre_page = SP_LIST;
        ui.force = 1;
        if (ui.pre_yes)
            pre_done(pre_save(ui.sel, ui.pre_eng, ui.pre_ix), "SAVED");
        else
            say("NOT SAVED", 1200);
        return;
    }
    if (pre_kind(ui.pre_eng, ui.pre_ix) < 0) {
        say("EMPTY", 900);
        return;
    }
    if (ui.engine[ui.sel] != ui.pre_eng) {       /* (the layer's engine moved on: to the presets' again) */
        ui.engine[ui.sel] = ui.pre_eng;
        ev_post(EV_ENGINE, ui.sel, 0, ui.pre_eng);
        mac_apply(ui.sel);
    }
    ui.pre_page = 0;
    pre_done(pre_load(ui.sel, ui.pre_eng, ui.pre_ix), "LOADED");
}

/* SAVE held */
static void save_long(void)
{
    if (ui.pre_page) {
        pre_long();
        return;
    }
    if (ui.snap_page) {                          /* the SNAPSHOTS page: the state now, into the snapshot framed */
        char n[8];
        fmt_int(n, ui.snap_ix + 1);
        if (snap_store(ui.snap_ix))
            flash("STORED", n, C_SNAP);
        else
            flash("FULL", n, C_BAD);
        ui.force = 1;
        return;
    }
    if (ui.ses_page == SP_ASK)
        return;
    ui.rv_page = ui.kit_page = ui.filter_page = ui.gr_page = ui.speed_page = ui.env_page = ui.bb_page = ui.bl_page = 0;
    if (ui.ses_page == SP_LIST && ui.ses_ix != ses_current()) {   /* in the list: into the slot shown, asked */
        ui.ses_new = ui.ses_ix;
        ui.ses_over = (uint8_t)ses_has(ui.ses_ix);
        ui.ses_page = SP_ASK;
        ui.ses_yes = (uint8_t)!ui.ses_over;      /* (over a session: NO until turned to YES) */
        ui.force = 1;
        return;
    }
    if (ses_current()) {                         /* a session loaded: saved over it, at once */
        ui.ses_page = ui.snap_page = 0;
        flash("SAVING", "", C_OK);
        ui_draw();
        ses_done(ses_save((uint32_t)ses_current()), "SAVED", (uint32_t)ses_current());
        return;
    }
    ui.ses_new = (uint16_t)ses_next_number();   /* none chosen: the first empty slot, asked first */
    if (!ui.ses_new) {
        ses_done(SES_FULL, "", 0);
        return;
    }
    ui.ses_over = 0;
    ui.ses_page = SP_ASK;
    ui.ses_yes = 1;
    ui.force = 1;
}
/* SAVE pressed (let go before it was held) */
static void save_short(void)
{
    if (ui.pre_page) {
        pre_short();
        return;
    }
    if (ui.ses_page == SP_ASK) {
        uint32_t num = ui.ses_new;
        ui.ses_page = ui.snap_page = 0;
        ui.force = 1;
        if (!ui.ses_yes) {
            say("NOT SAVED", 1500);
            return;
        }
        flash("SAVING", "", C_OK);
        ui_draw();
        ses_done(ses_save(num), "SAVED", num);
        return;
    }
    if (ui.ses_page == SP_LIST) {                /* the slot shown: loaded (or, empty, chosen), and back */
        uint32_t num = ui.ses_ix;
        ui.ses_page = ui.snap_page = 0;
        ui.force = 1;
        if (ses_has(num)) {
            flash("LOADING", "", C_SES);
            ui_draw();
            ses_done(ses_load_slot(num), "LOADED", num);
        } else {
            char n[8];
            flash("NEW", "", C_SES);
            ui_draw();
            ses_fresh(num);                      /* a clean slate, as at start; SAVE held writes it there */
            fmt_int(n, (int32_t)num);
            flash("NEW", n, C_WHITE);
        }
        return;
    }
    if (ui.snap_page) {                          /* the SNAPSHOTS page: back */
        ui.snap_page = 0;
        ui.force = 1;
        return;
    }
    ui.kit_page = ui.filter_page = ui.gr_page = ui.speed_page = ui.rv_page = ui.env_page = ui.bb_page = ui.bl_page = ui.sc_page = ui.mod_page = ui.rx_page = 0;   /* the SNAPSHOTS
                                                                                                      * page, framed
                                                                                                      * on the last */
    ui.snap_page = 1;
    ui.snap_key = -1;
    if (snap_current() >= 0)
        ui.snap_ix = (uint8_t)snap_current();
    ui.force = 1;
}
/* SHIFT + SAVE let go soon: the SESSIONS page, on the session chosen if any; on it, back (a question: not saved) */
static void ses_page_toggle(void)
{
    if (ui.ses_page == SP_ASK)
        say("NOT SAVED", 1500);
    if (ui.ses_page) {
        ui.ses_page = ui.snap_page = 0;
        ui.force = 1;
        return;
    }
    ui.kit_page = ui.filter_page = ui.gr_page = ui.speed_page = ui.rv_page = ui.env_page = ui.bb_page = ui.bl_page = ui.sc_page = ui.mod_page = ui.rx_page = ui.snap_page = 0;
    ui.pre_page = 0;
    ui.ses_page = SP_LIST;
    ui.ses_ix = (uint8_t)(ses_current() ? ses_current() : 1);
    ui.force = 1;
}

static uint32_t next_seed(void);
/* a scale and a root drawn at random: the machine at start, and an empty session */
static void scale_draw(void)
{
    ui.scale = (uint8_t)((next_seed() >> 8) % NSCALE);
    ui.root = (uint8_t)((next_seed() >> 8) % 12u);
}
static uint32_t next_seed(void)
{
#if TELEMETRY
    ui.seed = ui.seed * 1664525u + 1013904223u;  /* (a diagnostic build: the same sounds at every start) */
#else
    ui.seed = ui.seed * 1664525u + 1013904223u + fm1_ticks();
#endif
    return ui.seed;
}

/* the macros of layer l's sound on the engine it plays, to the ISR */
static void mac_apply(uint32_t l)
{
    uint32_t j, e = ui.engine[l];
    for (j = 0; j < NMAC; j++)
        lay_mac[l][j] = ui.mac[l][e][j];
    for (j = 0; j < 4u; j++)                     /* (the track's own envelope: its values, then whether it is on) */
        lay_env[l][j] = ui.env[l][e][j];
    lay_env_on[l] = ui.env_on[l][e];
    ba_register[l] = ui.oct[l];
    ui.env_nat_ok = 0;                           /* (the sound may be another: read again) */
}

/* the ENVELOPE page: the sound's own amplitude envelope read as A D S R knob positions (FM: its loudest carrier;
 * CALIGULA: its pairs' times averaged; RUSSOLO and CALIGULA have no decay or sustain: 5 ms, 100 %) */
static void env_native(uint32_t l, int8_t *v)
{
    int32_t a[4];
    uint32_t e = ui.engine[l], k;
    if (e == ENG_FM)
        fm_env_adsr(&fm_buf[l][fm_pub[l]], a);
    else if (e == ENG_ANIMA) {
        const an_design_t *d = &an_buf[l][an_pub[l]];
        a[0] = d->att;
        a[1] = d->hold + d->dec;
        a[2] = (d->sus * 100 + Q15 / 2) / Q15;
        a[3] = d->rel;
    } else if (e == ENG_CAL) {
        const cal_design_t *d = &cal_buf[l][cal_pub[l]];
        a[0] = a[3] = 0;
        for (k = 0; k < 4u; k++) {
            a[0] += d->att[k] / 4;
            a[3] += d->rel[k] / 4;
        }
        a[1] = 5;
        a[2] = 100;
    } else if (e == ENG_DRUID)
        dr_env_adsr(&dr_buf[l][dr_pub[l]], a);
    else if (e == ENG_BAY)
        ba_env_adsr(&ba_buf[l][ba_pub[l]], a);
    else if (e == ENG_HIVE)
        hv_env_adsr(&hv_buf[l][hv_pub[l]], a);
    else if (e == ENG_OB)
        ob_env_adsr(&ob_buf[l][ob_pub[l]], a);
    else {
        const rus_design_t *d = &rus_buf[l][rus_pub[l]];
        a[0] = d->att;
        a[1] = 5;
        a[2] = 100;
        a[3] = d->rel;
    }
    for (k = 0; k < 4u; k++)
        v[k] = (int8_t)(k == 2u ? clampi(a[2], 0, 100) : env_val(k, a[k]));
}
/* what the page shows: the track's own envelope, or the sound's */
static const int8_t *env_shown(void)
{
    uint32_t l = ui.sel, e = ui.engine[l];
    if (ui.env_on[l][e])
        return ui.env[l][e];
    if (!ui.env_nat_ok) {
        env_native(l, ui.env_nat);
        ui.env_nat_ok = 1;
    }
    return ui.env_nat;
}
/* the name of EDIT's macro j on layer l's sound */
static const char *mac_name(uint32_t l, uint32_t j)
{
    uint32_t e = ui.engine[l];
    return e == ENG_FM ? fm_mac_name(&fm_buf[l][fm_pub[l]], j) : e == ENG_ANIMA ? an_mac_name(&an_buf[l][an_pub[l]], j)
           : e == ENG_CAL ? cal_mac_name(&cal_buf[l][cal_pub[l]], j) : e == ENG_RUS ? rus_mac_name(&rus_buf[l][rus_pub[l]], j)
           : e == ENG_DRUID ? dr_mac_name(&dr_buf[l][dr_pub[l]], j) : e == ENG_BAY ? ba_mac_name(&ba_buf[l][ba_pub[l]], j)
           : e == ENG_OB ? ob_mac_name(&ob_buf[l][ob_pub[l]], j) : hv_mac_name(&hv_buf[l][hv_pub[l]], j);
}

/* the family (kind, species) layer l plays on its engine now */
static int32_t cur_kind(uint32_t l)
{
    return ui.engine[l] == ENG_FM    ? (int32_t)fm_buf[l][fm_pub[l]].family
           : ui.engine[l] == ENG_ANIMA ? (int32_t)an_buf[l][an_pub[l]].kind
           : ui.engine[l] == ENG_CAL   ? (int32_t)cal_buf[l][cal_pub[l]].kind
           : ui.engine[l] == ENG_RUS   ? (int32_t)rus_buf[l][rus_pub[l]].kind
           : ui.engine[l] == ENG_DRUID ? (int32_t)dr_buf[l][dr_pub[l]].kind
           : ui.engine[l] == ENG_BAY   ? (int32_t)ba_buf[l][ba_pub[l]].kind
           : ui.engine[l] == ENG_OB    ? (int32_t)ob_buf[l][ob_pub[l]].kind
                                       : (int32_t)hv_buf[l][hv_pub[l]].kind;
}
static uint32_t cur_seed(uint32_t l)             /* (the seed of the sound layer l plays on its engine now) */
{
    return ui.engine[l] == ENG_FM    ? fm_buf[l][fm_pub[l]].seed
           : ui.engine[l] == ENG_ANIMA ? an_buf[l][an_pub[l]].seed
           : ui.engine[l] == ENG_CAL   ? cal_buf[l][cal_pub[l]].seed
           : ui.engine[l] == ENG_RUS   ? rus_buf[l][rus_pub[l]].seed
           : ui.engine[l] == ENG_DRUID ? dr_buf[l][dr_pub[l]].seed
           : ui.engine[l] == ENG_BAY   ? ba_buf[l][ba_pub[l]].seed
           : ui.engine[l] == ENG_OB    ? ob_buf[l][ob_pub[l]].seed
                                       : hv_buf[l][hv_pub[l]].seed;
}
/* a new sound for the layer chosen, of family kind (-1: any); msg said first (0: none, the family's name shows) */
static void new_sound_of(int32_t kind, const char *msg)
{
    uint32_t l = ui.sel;
    int ok;
    new_kind = kind;
    if (msg)
        say(msg, 900);
    ui.home_until = fm1_ms + (msg ? 400u : 300u);
    ui_draw();                                   /* the message first: an FM patch takes ~30 ms to measure */
    ok = ui.engine[l] == ENG_FM      ? new_fm(l, next_seed(), ui.path[l])
         : ui.engine[l] == ENG_ANIMA ? new_anima(l, next_seed(), ui.path[l])
         : ui.engine[l] == ENG_CAL   ? new_cal(l, next_seed(), ui.path[l])
         : ui.engine[l] == ENG_RUS   ? new_rus(l, next_seed(), ui.path[l])
         : ui.engine[l] == ENG_DRUID ? new_druid(l, next_seed(), ui.path[l])
         : ui.engine[l] == ENG_BAY   ? new_bay(l, next_seed(), ui.path[l])
         : ui.engine[l] == ENG_OB    ? new_ob(l, next_seed(), ui.path[l])
                                     : new_hive(l, next_seed(), ui.path[l]);
    new_kind = -1;
    if (!ok)
        say("BUSY", 900);
    else {                                       /* a new sound: as drawn, no macros */
        memset(ui.mac[l][ui.engine[l]], 0, NMAC);
        ui.env_on[l][ui.engine[l]] = 0;          /* (its own envelope too) */
        mac_apply(l);
        mod_draw(l, ui.engine[l], (uint32_t)cur_kind(l), cur_seed(l), ui.path[l]);   /* (its modulation, or none) */
    }
}
/* HOME: a new sound for the layer chosen; same: of the family it plays now (SHIFT + HOME) */
static void new_sound(int same) { new_sound_of(same ? cur_kind(ui.sel) : -1, same ? "SAME FAMILY" : "NEW"); }

/* --------------------------------------------------------------- input --- */
static int32_t enc_take(uint32_t role) { return fm1_enc_take(PANEL_ENC[role]); }
/* KNOB 1 .. 4 for their own functions: with SHIFT held, KNOB 3 and 4 are SHIFT's (distortion, delay send) -- a
 * click arriving between SHIFT's read and this one must not reach the crush or the reverb send */
static int32_t knob_take(uint32_t role, int sh) { return sh && (role == EN_K3 || role == EN_K4) ? 0 : enc_take(role); }
static int btn_bit(uint32_t mask, uint32_t label) { return (int)((mask >> PANEL_BTN[label]) & 1u); }

/* GLOBAL SETUP and the MIDI in (setup.c, after the sessions') */
static void setup_open(void);
static void setup_press(int sh);
static void setup_preset(int32_t s);
static void setup_draw(void);
static void midi_take(void);
static void mod_knob(uint32_t l, uint32_t ix, uint32_t j, int32_t s);   /* (the MOD page: below) */
static void draw_mod_page(void);
static int32_t batt_raw;                         /* the battery's divider, smoothed (main.c), 0 .. 1023; 0 none yet */

static void ui_input(void)
{
    uint32_t rel, press = fm1_input_edges(&rel), keys, ch, k, l;
    int32_t s;
    int sh;
    {   /* CPU1 retired as it plays (a fault, a stall, a misread): said, once */
        static uint8_t was_on;
        if (was_on && !audio_worker_online)
            say("1 CORE", 4000);
        was_on = (uint8_t)audio_worker_online;
    }
    morph_poll();                                /* (a snapshot's morph, a step on) */
    bb_tick();                                   /* (the balls: their time, their notes) */
    bl_tick();                                   /* (BRICKLAYER's steps) */
    rx_tick();                                   /* (REACT, SHADOW, ARPEGGIO: listening, and the tracks' notes) */
    if (ui.vary_shown && loop[ui.sel].vary == ui.vary_shown - 1u)
        ui.vary_shown = 0;                       /* (VARY taken by the ISR: shown from the looper again) */
    (void)rel;
    for (l = 0; l < NLAYER; l++)
        if (btn_bit(press, LAYER_BTN[l]) && rx_page_up()) {
            if((fm1_in.notes>>KEY_SHIFT)&1u) {
                ui.sel=(uint8_t)l;rx.guide=(uint8_t)l;rx.mask&=(uint8_t)~(1u<<l);
                rx_reset();say("GUIDE CHANGED",1200);ui.force=1;
            } else rx_pad_hit(l);
        }                       /* (the PLAY ALONG page: the track in or out; the guide stays) */
        else if (btn_bit(press, LAYER_BTN[l])) {
            ui.trk_down = (uint8_t)(l + 1u);
            ui.trk_t0 = fm1_ms;
            ui.trk_done = 0;
            ui.sel = (uint8_t)l;
            if(ui.engine[l]!=ENG_ANIMA)ui.acid_page=0;
            ui.force=1;
            ui.kit_page = ui.filter_page = ui.gr_page = ui.speed_page = 0;
            ui.vary_shown = 0;
            ui.env_nat_ok = 0;
            if (ui.rv_page || ui.ses_page || ui.snap_page || ui.sc_page || ui.pre_page || ui.env_page || ui.bb_page || ui.bl_page || ui.mod_page ||
                ui.set_page) {   /* a layer chosen:
                                                                                                    * back to it */
                ui.rv_page = 0;
                ui.kit_page = ui.filter_page = ui.gr_page = ui.speed_page = ui.env_page = ui.bb_page = ui.bl_page = 0;
                ui.ses_page = ui.snap_page = 0;
                ui.sc_page = 0;
                ui.pre_page = ui.set_page = ui.mod_page = ui.rx_page = 0;
                ui.force = 1;
            }
        }
    if (ui.trk_down) {                           /* a track's button held: it is copied, or the copy pasted onto it */
        l = ui.trk_down - 1u;
        if (!btn_bit(fm1_in.buttons, LAYER_BTN[l]))
            ui.trk_down = 0;
        else if ((fm1_in.notes >> KEY_SHIFT) & 1u)
            ui.trk_done = 1;                     /* (with SHIFT: the track's transposition, never a copy) */
        else if (!ui.trk_done && (uint32_t)(fm1_ms - ui.trk_t0) >= 800u) {
            char n[12] = "TRACK ";
            ui.trk_done = 1;
            n[6] = (char)('1' + l);
            n[7] = 0;
            if (clip_from() >= 0 && clip_from() != (int)l) {
                flash("PASTING", n, ui_color(l));
                ui_draw();
                clip_paste(l);
                flash("PASTED", n, ui_color(l));
            } else {
                clip_copy(l);
                flash("COPIED", n, ui_color(l));
            }
        }
    }
    if (btn_bit(press, B_SEQ) && (fm1_in.notes >> KEY_SHIFT) & 1u) {   /* SHIFT and SEQ: the chosen track's modulation
                                                                         * thrown anew (both LFOs, the slots) */
        mod_random(ui.sel, next_seed());
        say("MOD RANDOM", 900);
        ui.mod_touched = -1;
        ui.force = 1;
    } else if (btn_bit(press, B_SEQ)) {          /* SEQ, again and again: DELAY, REVERB, MOD, PLAY ALONG, back to
                                                  * playing */
        if(ui.gr_page) {ui.gr_page=ui.gr_page==1?2:1;ui.force=1;return;}
        if(ui.acid_page) ui.acid_page=0;
        else if (ui.clock_page) {ui.clock_page=0;ui.acid_page=ui.engine[ui.sel]==ENG_ANIMA;}
        else if (ui.rx_page) { ui.rx_page=0; ui.clock_page=1; }
        else if (ui.mod_page) {
            ui.mod_page = 0;
            ui.rx_page = 1;
            rx_defaults();
        } else if (ui.rv_page==1) ui.rv_page=2;
        else if (ui.rv_page && ui.fx) {ui.fx=0;ui.rv_page=1;}
        else if (ui.rv_page) {
            ui.rv_page = 0;
            ui.mod_page = 1;
            ui.mod_touched = -1;
        } else {
            ui.rv_page = 1;
            ui.fx = 1;
        }
        ui.kit_page = ui.filter_page = ui.gr_page = ui.speed_page = ui.env_page = ui.bb_page = ui.bl_page = 0;
        ui.ses_page = ui.snap_page = 0;
        ui.pre_page = ui.set_page = 0;
        ui.sc_page = 0;
        ui.force = 1;
    }
    if (btn_bit(press,B_ARP)) ui.clock_page=ui.acid_page=0;
    if (btn_bit(press, B_ARP) && (fm1_in.notes >> KEY_SHIFT) & 1u) {   /* SHIFT and ARP: the presets, or back */
        if (ui.pre_page)
            ui.pre_page = 0;
        else {
            ui.pre_page = SP_LIST;
            ui.pre_eng = ui.engine[ui.sel];
            if (!ui.pre_ix)
                ui.pre_ix = 1;
            ui.kit_page = ui.filter_page = ui.gr_page = ui.speed_page = ui.rv_page = ui.ses_page = ui.snap_page = ui.sc_page = ui.env_page = ui.bb_page = ui.bl_page = ui.set_page = ui.mod_page = ui.rx_page = 0;
        }
        ui.force = 1;
    } else if (btn_bit(press, B_ARP) && ui.pre_page) {   /* the PRESETS page (where SHIFT + ARP opens it): ARP held saves
                                                          * into the slot, pressed loads it (or answers OVERWRITE?) */
        ui.arp_t0 = fm1_ms;
        ui.arp_down = 1;
        ui.arp_long = 0;
    } else if (btn_bit(press, B_ARP)) {
        ui.sc_page = (uint8_t)!ui.sc_page;
        ui.rv_page = 0;
        ui.kit_page = ui.filter_page = ui.gr_page = ui.speed_page = ui.env_page = ui.bb_page = ui.bl_page = 0;
        ui.ses_page = ui.snap_page = 0;
        ui.pre_page = ui.set_page = ui.mod_page = ui.rx_page = 0;
        ui.force = 1;
    }
    if (btn_bit(press,B_SAVE)) ui.clock_page=ui.acid_page=0;
    if (btn_bit(press, B_SAVE) && (fm1_in.notes >> KEY_SHIFT) & 1u) {   /* SHIFT and SAVE: the SESSIONS page; held,
                                                                         * GLOBAL SETUP; in it, back */
        if (ui.set_page)
            setup_press(1);
        else {
            ui.ssv_t0 = fm1_ms;
            ui.ssv_down = 1;
            ui.ssv_long = 0;
        }
    } else if (btn_bit(press, B_SAVE) && ui.set_page)
        setup_press(0);                          /* (SAVE in GLOBAL SETUP: into, or set) */
    else if (btn_bit(press, B_SAVE)) {
        ui.save_t0 = fm1_ms;
        ui.save_down = 1;
        ui.save_long = 0;
    }
    if (ui.arp_down) {
        if (!btn_bit(fm1_in.buttons, B_ARP)) {
            ui.arp_down = 0;
            if (!ui.arp_long && ui.pre_page)
                pre_short();
        } else if (!ui.arp_long && (uint32_t)(fm1_ms - ui.arp_t0) >= 800u) {
            ui.arp_long = 1;
            if (ui.pre_page)
                pre_long();
        }
    }
    if (ui.ssv_down) {
        if (!btn_bit(fm1_in.buttons, B_SAVE)) {
            ui.ssv_down = 0;
            if (!ui.ssv_long)
                ses_page_toggle();
        } else if (!ui.ssv_long && (uint32_t)(fm1_ms - ui.ssv_t0) >= 800u) {
            ui.ssv_long = 1;
            ui.ses_page = ui.snap_page = 0;
            setup_open();
        }
    }
    if (ui.save_down) {
        if (!btn_bit(fm1_in.buttons, B_SAVE)) {
            ui.save_down = 0;
            if (!ui.save_long)
                save_short();
        } else if (!ui.save_long && (uint32_t)(fm1_ms - ui.save_t0) >= 800u) {
            ui.save_long = 1;
            save_long();
        }
    }
    sh = (int)((fm1_in.notes >> KEY_SHIFT) & 1u);  /* (SHIFT read once: the knobs below all see the same) */
    if (sh && !(ui.bl_page && ui.engine[ui.sel]==ENG_ANIMA) && !ui.acid_page && !ui.clock_page && !ui.rv_page && !ui.kit_page && !ui.filter_page && !ui.gr_page && !ui.snap_page && (s = enc_take(EN_K4)) != 0) {   /* SHIFT + KNOB 4: the track's delay send */
        ui.dsend[ui.sel] = (int8_t)clampi(ui.dsend[ui.sel] + 2 * s, 0, 100);
        level_pan_apply(ui.sel);
        ui.dial = DIAL_DSEND;
        ui.dial_until = fm1_ms + 1000u;
    }
    if (sh && !(ui.bl_page && ui.engine[ui.sel]==ENG_ANIMA) && !ui.acid_page && !ui.clock_page && !ui.rv_page && !ui.kit_page && !ui.filter_page && !ui.gr_page && !ui.snap_page && (s = enc_take(EN_K3)) != 0) {   /* SHIFT + KNOB 3: the track's distortion */
        ui.dist[ui.sel] = (int8_t)clampi(ui.dist[ui.sel] + 2 * s, 0, 100);
        level_pan_apply(ui.sel);
        ui.dial = DIAL_DIST;
        ui.dial_until = fm1_ms + 1000u;
    }
    if(ui.acid_page) {
        static const uint8_t controls[4]={EN_K1,EN_K2,EN_K3,EN_K4};
        static const int16_t maximum[4]={2,100,500,100};
        for(uint32_t j=0;j<4;j++)if((s=enc_take(controls[j]))) {acid_edit[ui.sel][j]=(int16_t)clampi(acid_edit[ui.sel][j]+s,0,maximum[j]);ui.force=1;}
    } else if (ui.clock_page) {
        uint32_t l=ui.sel,t=ui.clock_target;
        if((s=enc_take(EN_K1))) {clk.bpm=(uint16_t)clampi(clk.bpm+s,30,300);ui.force=1;}
        if((s=enc_take(EN_K2))) {ui.clock_target=(uint8_t)clampi((int)t+s,0,2);t=ui.clock_target;ui.force=1;}
        if((s=enc_take(EN_K3))) {
            uint8_t mode=(uint8_t)clampi((int)clk.mode[l][t]+s,0,1);
            if(t==CK_LOOP && loop[l].rec!=LR_IDLE) {say("FINISH REC",1200);mode=clk.mode[l][t];}
            if(mode!=clk.mode[l][t]) { clock_cancel[l][t]++; clk.mode[l][t]=mode;
                if(t==CK_BALL) bb_release(l);
                if(t==CK_BRICK) {bl_release(l);bl.due[l]=fm1_ms;bl.pos[l]=0;}
            } ui.force=1;
        }
        if((s=enc_take(EN_K4))) {
            if(sh && t==CK_LOOP) {clk.bars[l]=(uint8_t)clampi((int)clk.bars[l]+s,1,64);memset(clk.take_bars[l],0,sizeof clk.take_bars[l]);}
            else clk.div[l][t]=(uint8_t)clampi((int)clk.div[l][t]+s,0,t==CK_LOOP?10:5);
            if(t!=CK_LOOP || sh)clock_cancel[l][t]++; ui.force=1;
        }
    } else if (ui.kit_page) {
        unsigned l=ui.sel;ba_kit_t kit;ba_kit_get(&ba_buf[l][ba_pub[l]],&kit);int changed=0;
        if((s=enc_take(EN_K1))){ui.kit_pad=(uint8_t)clampi(ui.kit_pad+s,0,15);ui.force=1;}
        unsigned pad=ui.kit_pad;
        if((s=enc_take(EN_K2))){kit.source[pad]=(uint8_t)ba_next_source(pad,kit.source[pad],s);changed=1;}
        if((s=enc_take(EN_K3))){kit.tune[pad]=(int8_t)clampi(kit.tune[pad]+s,-24,24);changed=1;}
        if((s=enc_take(EN_K4))){if(s>0)kit.locks|=1u<<pad;else kit.locks&=~(1u<<pad);changed=1;}
        if(changed){if(!ba_edit_kit(l,&kit))say("WAIT / RETRY",500);ui.force=1;}
    } else if (ui.filter_page) {
        if ((s=enc_take(EN_K1))) {
            if (sh) ui.filter_page=0;
            else { ui.flt[ui.sel]=(int8_t)clampi(ui.flt[ui.sel]+2*s,-FLT_MAX,FLT_MAX); level_pan_apply(ui.sel); }
            ui.force=1;
        }
        if ((s=enc_take(EN_K2))) { flt_edit[ui.sel][1]=(int8_t)clampi(flt_edit[ui.sel][1]+s,0,101); ui.force=1; }
        if ((s=enc_take(EN_K3))) { flt_edit[ui.sel][0]=(int8_t)clampi(flt_edit[ui.sel][0]+s,0,6); ui.force=1; }
        enc_take(EN_K4);
    } else if (ui.gr_page) {
        static const uint8_t K[4] = {EN_K1, EN_K2, EN_K3, EN_K4};
        for (uint32_t j = 0; j < 4u; j++) {
            s = enc_take(K[j]);
            if (s && sh && j == 1u) { ui.gr_page = 0; ui.force = 1; break; }
            if (s) {
                if(ui.gr_page==1)gr_edit[ui.sel][j]=(int8_t)clampi(gr_edit[ui.sel][j]+s,-100,100);
                else fx.grain[ui.sel][j]=(int8_t)clampi(fx.grain[ui.sel][j]+s,j?0:-24,j==0?24:j==2?1:100);
                ui.force=1;
            }
        }
    } else if (ui.speed_page) {
        uint32_t l = ui.sel;
        if ((s = knob_take(EN_K1, sh)) != 0) {
            uint32_t pct = loop_pct(loop[l].speed_pct);
            if (loop[l].rate == LS_HALF) pct /= 2u;
            else if (loop[l].rate == LS_DOUBLE) pct *= 2u;
            ev_post(EV_LOOP_SPEED, l, LOOP_TRK, (uint32_t)clampi((int32_t)pct + s, 25, 400));
        }
        if ((s = knob_take(EN_K2, sh)) != 0)
            ui.speed_loop = (uint8_t)clampi((int32_t)ui.speed_loop + s, 0, loop[l].ntrk ? loop[l].ntrk - 1 : 0);
        if ((s = knob_take(EN_K3, sh)) != 0 && ui.speed_loop < loop[l].ntrk)
            ev_post(EV_LOOP_SPEED, l, ui.speed_loop, (uint32_t)clampi((int32_t)loop_pct(loop[l].trk[ui.speed_loop].speed_pct) + s, 25, 400));
        enc_take(EN_K4);
        ui.force = 1;
    } else if (ui.snap_page) {                          /* the SNAPSHOTS page: KNOB 1 the morph time (its dial); 2 .. 4 nothing */
        if ((s = enc_take(EN_K1)) != 0) {
            ui.morph = (uint8_t)clampi((int32_t)ui.morph + s, 0, MORPH_STEPS);
            ui.morph_until = fm1_ms + 1500u;
        }
        enc_take(EN_K2);
        enc_take(EN_K3);
        enc_take(EN_K4);
    } else if (rx_page_up()) {                   /* the PLAY ALONG page: KNOB 1 .. 4 the mode's (ARPEGGIO: SELECT and
                                                  * ALGORITHM its fifth and sixth, below) */
        static const uint8_t K[4] = {EN_K1, EN_K2, EN_K3, EN_K4};
        uint32_t j;
        for (j = 0; j < 4u; j++)
            if ((s = knob_take(K[j], sh)) != 0) {
                rx_knob(j, s);
                rx_focus = (uint8_t)j;
            }
    } else if (ui.env_page) {                    /* KNOB 1 .. 4: the track's own envelope, A D S R; the first turn
                                                  * takes it from the sound's own (as drawn) */
        static const uint8_t K[4] = {EN_K1, EN_K2, EN_K3, EN_K4};
        uint32_t j, l = ui.sel, e = ui.engine[l];
        for (j = 0; j < 4u; j++) {
            s = knob_take(K[j], sh);
            if (s) {
                if (!ui.env_on[l][e]) {
                    memcpy(ui.env[l][e], env_shown(), 4);
                    ui.env_on[l][e] = 1;
                }
                ui.env[l][e][j] = (int8_t)clampi(ui.env[l][e][j] + 2 * s, 0, 100);
                mac_apply(l);
                ui.env_touched = (int8_t)j;
                ui.env_touch_until = fm1_ms + 1500u;
            }
        }
    } else if (ui.bl_page && bl.on[ui.sel] && sh && ui.engine[ui.sel]==ENG_ANIMA) {
        uint32_t l=ui.sel;int changed=0;
        if((s=enc_take(EN_K1))) {bl_edit_note[l]=(uint8_t)clampi((int)bl_edit_note[l]+s,0,bl.n[l]?bl.n[l]-1:0);changed=1;}
        if((s=enc_take(EN_K2))) {bl_accent[l][bl_edit_note[l]]=(uint8_t)clampi((int)bl_accent[l][bl_edit_note[l]]+s,0,1);changed=1;}
        if((s=enc_take(EN_K3))) {bl_slide[l][bl_edit_note[l]]=(uint8_t)clampi((int)bl_slide[l][bl_edit_note[l]]+s,0,1);changed=1;}
        enc_take(EN_K4);
        if(changed) {char msg[32];fmt_int(msg,bl_edit_note[l]+1);str_cpy(msg+str_len(msg),bl_accent[l][bl_edit_note[l]]?" ACC":" ---",sizeof msg-str_len(msg));str_cpy(msg+str_len(msg),bl_slide[l][bl_edit_note[l]]?" SLIDE":" -----",sizeof msg-str_len(msg));say(msg,1600);ui.force=1;}
    } else if (ui.bl_page && bl.on[ui.sel]) {    /* BRICKLAYER's page: KNOB 1 .. 4 its */
        static const uint8_t K[4] = {EN_K1, EN_K2, EN_K3, EN_K4};
        uint32_t j;
        for (j = 0; j < 4u; j++)
            if ((s = knob_take(K[j], sh)) != 0)
                bl_knob(ui.sel, j, s);
    } else if (ui.bb_page && bb.on[ui.sel]) {    /* the chosen track's balls' page: KNOB 1 .. 4 theirs */
        static const uint8_t K[4] = {EN_K1, EN_K2, EN_K3, EN_K4};
        uint32_t j;
        for (j = 0; j < 4u; j++)
            if ((s = knob_take(K[j], sh)) != 0)
                bb_knob(ui.sel, j, s);
    } else if (ui.mod_page) {                    /* KNOB 1..4: the MOD entry's */
        static const uint8_t K[4] = {EN_K1, EN_K2, EN_K3, EN_K4};
        uint32_t j;
        for (j = 0; j < 4u; j++)
            if ((s = knob_take(K[j], sh)) != 0)
                mod_knob(ui.sel, ui.mod_ix, j, s);
    } else if (ui.rv_page) {                     /* KNOB 1..4: the reverb, or the delay */
        static const uint8_t K[4] = {EN_K1, EN_K2, EN_K3, EN_K4};
        uint32_t j;
        int8_t *pv = ui.rv_page==2?(ui.fx?fx.dl:fx.rv):(ui.fx?ui.dlp:ui.rvp);
        for (j = 0; j < 4u; j++) {
            s = knob_take(K[j], sh);
            if (s) {
                int hi=ui.rv_page==2?(ui.fx?(j==0?4:j==1?5:j==2?3:100):(j?100:5)):100;
                pv[j]=(int8_t)clampi(pv[j]+(hi<100?1:2)*s,0,hi);
                if (ui.fx)
                    dl_param(ui.dlp[0], ui.dlp[1], ui.dlp[2], ui.dlp[3]);
                else
                    rv_param(ui.rvp[0], ui.rvp[1], ui.rvp[2], ui.rvp[3]);
                ui.rv_touched = (int8_t)j;
                ui.rv_touch_until = fm1_ms + 1500u;
            }
        }
    } else if (ui.edit) {                        /* EDIT: KNOB 1 .. 4, the sound's macros; each its dial */
        static const uint8_t K[4] = {EN_K1, EN_K2, EN_K3, EN_K4};
        uint32_t j;
        for (j = 0; j < NMAC; j++) {
            s = knob_take(K[j], sh);
            if (s) {
                int8_t *m = &ui.mac[ui.sel][ui.engine[ui.sel]][j];
                *m = (int8_t)clampi(*m + 2 * s, -MAC_MAX, MAC_MAX);
                mac_apply(ui.sel);
                ui.dial = (uint8_t)(DIAL_MAC + j);
                ui.dial_until = fm1_ms + 1000u;
            }
        }
    } else {
        s = enc_take(EN_K1);                     /* KNOB 1: the layer's filter; its dial over the screen */
        if (s && sh) { ui.filter_page=1; ui.dial_until=0; ui.force=1; }
        else if (s) {
            ui.flt[ui.sel] = (int8_t)clampi(ui.flt[ui.sel] + 2 * s, -FLT_MAX, FLT_MAX);
            level_pan_apply(ui.sel);
            ui.dial = DIAL_FLT;
            ui.dial_until = fm1_ms + 1000u;
        }
        s = enc_take(EN_K2);                     /* KNOB 2: the layer's granulator */
        if (s && sh) {
            ui.gr_page = 1; ui.dial_until = 0; ui.force = 1;
        } else if (s) {
            ui.gr[ui.sel] = (int8_t)clampi(ui.gr[ui.sel] + 2 * s, -FLT_MAX, FLT_MAX);
            level_pan_apply(ui.sel);
            ui.dial = DIAL_GR;
            ui.dial_until = fm1_ms + 1000u;
        }
        s = knob_take(EN_K3, sh);                /* KNOB 3: the layer's crush */
        if (s) {
            ui.cr[ui.sel] = (int8_t)clampi(ui.cr[ui.sel] + 2 * s, -FLT_MAX, FLT_MAX);
            level_pan_apply(ui.sel);
            ui.dial = DIAL_CR;
            ui.dial_until = fm1_ms + 1000u;
        }
        s = knob_take(EN_K4, sh);                /* KNOB 4: the layer's send */
        if (s) {
            ui.send[ui.sel] = (int8_t)clampi(ui.send[ui.sel] + 2 * s, 0, 100);
            level_pan_apply(ui.sel);
            ui.dial = DIAL_SEND;
            ui.dial_until = fm1_ms + 1000u;
        }
    }
    if (btn_bit(press, B_HOME)) {
        if(ui.kit_page){ba_kit_t kit;ba_kit_get(&ba_buf[ui.sel][ba_pub[ui.sel]],&kit);ba_kit_random(&kit,next_seed(),sh?ui.kit_pad:-1);say(ba_edit_kit(ui.sel,&kit)?"KIT RANDOM":"WAIT / RETRY",700);ui.force=1;}
        else new_sound((int)((fm1_in.notes >> KEY_SHIFT) & 1u));
    }
    if (ui.bl_page && bl.on[ui.sel] && btn_bit(press, B_REC)) {   /* BRICKLAYER's page: REC is its entry */
        if (sh) {                                /* SHIFT and REC: the last note out */
            if (bl.n[ui.sel])
                bl.n[ui.sel]--;
            say("LAST OUT", 900);
        } else {
            ui.blrec_down = 1;
            ui.blrec_done = 0;
            ui.blrec_t0 = fm1_ms;
        }
        ui.force = 1;
    } else if (btn_bit(press, B_REC) && sh) {    /* SHIFT and REC: the chosen track's loops VARY (or as played) */
        uint32_t v = !loop[ui.sel].vary;
        ev_post(EV_LOOP_MODE, ui.sel, 2, v);
        say(v ? "VARY" : "VARY OFF", 1200);
        ui.vary_shown = (uint8_t)(v + 1u);
        ui.force = 1;
    } else if (btn_bit(press, B_REC)) {          /* the looper: at once (the loop ends exactly here) */
        const looper_t *p = &loop[ui.sel];
        char m[12] = "LOOP ";
        ev_post(EV_LOOP_REC, ui.sel, 0, 0);
        if(clk.mode[ui.sel][CK_LOOP] && p->rec==LR_IDLE) say("ARM NEXT BAR",1200);
        ui.rec_t0 = fm1_ms;
        ui.rec_down = 1;
        ui.rec_done = 0;
        if (p->rec == LR_REC) {                  /* ended: LOOP n */
            fmt_int(m + 5, p->ntrk + 1);
            say(clk.mode[ui.sel][CK_LOOP]?"CLOSE ON BAR":m, 1200);
        } else if (p->rec == LR_IDLE && p->ntrk >= LOOP_TRK)
            say("10 LOOPS", 1500);               /* full: not armed */
        else if (p->rec == LR_IDLE && p->nev >= LOOP_N - 32u)
            say("LOOPER FULL", 1500);            /* (its notes, and the snapshots' loops: not armed) */
    }
    if (ui.blrec_down) {                         /* (BRICKLAYER: held 1 s, emptied; let go soon, entry on or off) */
        if (!btn_bit(fm1_in.buttons, B_REC)) {
            ui.blrec_down = 0;
            if (!ui.blrec_done) {
                bl.rec[ui.sel] = (uint8_t)!bl.rec[ui.sel];
                say(bl.rec[ui.sel] ? "REC" : "REC OFF", 900);
            }
        } else if (!ui.blrec_done && (uint32_t)(fm1_ms - ui.blrec_t0) >= 1000u) {
            ui.blrec_done = 1;
            bl.n[ui.sel] = 0;
            bl.len[ui.sel] = 0;
            bl.pos[ui.sel] = 0;
            bl_release(ui.sel);
            flash("BRICKS", "EMPTY", ui_color(ui.sel));
        }
        ui.force = 1;
    }
    if (ui.rec_down && !btn_bit(fm1_in.buttons, B_REC))
        ui.rec_down = 0;
    if (ui.rec_down && !ui.rec_done && (uint32_t)(fm1_ms - ui.rec_t0) >= 1000u) {   /* held: emptied */
        ev_post(EV_LOOP_EMPTY, ui.sel, 0, 0);    /* (the events the snapshots hold stay) */
        snap_loop_emptied(ui.sel);
        ui.lxt[ui.sel] = 0;                      /* (emptied: its own transposition gone too) */
        lx_post();
        char d[8] = "LOOP  ";
        ui.rec_done = 1;
        d[5] = (char)('1' + ui.sel);
        flash(d, "EMPTY", ui_color(ui.sel));
    }
    if (btn_bit(press, B_PLAY)) {
        if ((fm1_in.notes >> KEY_SHIFT) & 1u) {  /* SHIFT and PLAY, any layer: every loop and sequencer stops if */
            uint32_t l, playing = 0, kept = 0;   /* one plays, else every one there is starts, together */
            for (l = 0; l < NLAYER; l++) {
                playing |= loop[l].play || bl.run[l] || bb.run[l];
                kept |= loop[l].ntrk != 0u || seq_on(l);
            }
            if (playing || kept) {
                ev_post(EV_LOOPS, 0, 0, (uint32_t)!playing);
                for (l = 0; l < NLAYER; l++) {
                    bl_set_run(l, !playing);
                    bb_set_run(l, !playing);
                }
            }
            say(playing ? "ALL STOPPED" : kept ? "ALL PLAYING" : "NOTHING", 1200);
        } else if (rx_page_up()) {               /* PLAY on the PLAY ALONG page: the mode on or off */
            rx_set(!rx.on);
            say(rx.on ? RXM_NAME[rx.mode] : RXM_OFF[rx.mode], 1200);
            ui.force = 1;
        } else if(ui.clock_page && ui.clock_target!=CK_LOOP && !seq_page()) {
            say("SEQ IS OFF",1000);
        } else if (seq_page()) {                 /* PLAY on a sequencer's page: it starts or stops */
            int run = !(bl.run[ui.sel] || bb.run[ui.sel]);
            bl_set_run(ui.sel, run);
            bb_set_run(ui.sel, run);
            say(run ? "PLAY" : "STOP", 700);
            ui.force = 1;
        } else {                                 /* PLAY: let go soon, the loops; held, the overdubs */
            ui.play_down = 1;
            ui.play_t0 = fm1_ms;
        }
    }
    if (ui.play_down) {
        if (!btn_bit(fm1_in.buttons, B_PLAY)) {
            ui.play_down = 0;
            if (ui.ovd) {
                ui.ovd = 0;
                ui.force = 1;
            } else
                ev_post(EV_LOOP_PLAY, ui.sel, 0, 0);
        } else if (!ui.ovd && (uint32_t)(fm1_ms - ui.play_t0) >= 450u) {
            ui.ovd = 1;                          /* held: the chosen layer's loops on the white keys */
            ui.force = 1;
        }
    }
    if (rx_page_up() && rx_nk() == 6u) {         /* ARPEGGIO's page: SELECT and ALGORITHM its RANGE and CHANCE */
        if ((s = enc_take(EN_SELECT)) != 0) {
            rx_knob(4, s);
            rx_focus = 4;
        }
        if ((s = enc_take(EN_ALGO)) != 0) {
            rx_knob(5, s);
            rx_focus = 5;
        }
    }
    if (ui.sc_page) {                            /* the SCALE page: SELECT the root, ALGORITHM the scale */
        s = enc_take(EN_ALGO);
        if (s) {
            ui.scale = (uint8_t)clampi((int32_t)ui.scale + s, 0, NSCALE - 1);
            lx_post();                           /* (the loops moved walk the new scale) */
            ui.sc_touched = 1;
            ui.sc_touch_until = fm1_ms + 1500u;
        }
        s = enc_take(EN_SELECT);
        if (s) {
            ui.root = (uint8_t)(((int32_t)ui.root + s % 12 + 12) % 12);   /* round the octave */
            lx_post();
            ui.sc_touched = 0;
            ui.sc_touch_until = fm1_ms + 1500u;
        }
    }
    s = enc_take(EN_SELECT);
    if (s) {                                     /* the level */
        char m[12] = "VOL ";                     /* as the knob's share of its turn: 0 .. 100 % */
        int32_t lv = clampi(ui.level[ui.sel] + s, 0, LEVEL_MAX);
        ui.level[ui.sel] = (int8_t)lv;
        level_pan_apply(ui.sel);
        if (lv == 0)
            str_cpy(m + 4, "OFF", 8);
        else {
            fmt_int(m + 4, (lv * 100 + LEVEL_MAX / 2) / LEVEL_MAX);
            str_cpy(m + str_len(m), "%", 2);
        }
        say(m, 1200);
    }
    s = enc_take(EN_ALGO);
    if (s) {                                     /* the pan */
        char m[12] = "PAN ";
        int32_t pn = clampi(ui.pan[ui.sel] + s, -PAN_MAX, PAN_MAX), pc = (pn < 0 ? -pn : pn) * 100 / PAN_MAX;
        ui.pan[ui.sel] = (int8_t)pn;
        level_pan_apply(ui.sel);
        if (!pn)
            str_cpy(m + 4, "C", 8);
        else {
            m[4] = pn < 0 ? 'L' : 'R';
            m[5] = ' ';
            fmt_int(m + 6, pc);
        }
        say(m, 1200);
    }
    if ((btn_bit(press, B_OCTDN) || btn_bit(press, B_OCTUP)) && (fm1_in.notes >> KEY_SHIFT) & 1u) {
        char m[16] = "TRANSP ";                  /* SHIFT and OCT: every loop a step of the scale down or up; */
        int32_t lim = 2 * SCALE_N[ui.scale], t = -1, x;   /* a track's button held too: that track's loops only */
        for (l = 0; l < NLAYER; l++)
            if (btn_bit(fm1_in.buttons, LAYER_BTN[l]))
                t = (int32_t)l;
        if (t >= 0) {
            x = clampi(ui.lxt[t] + (btn_bit(press, B_OCTUP) ? 1 : -1), -lim, lim);
            latch_move((uint32_t)t, x - ui.lxt[t]);   /* (its latched notes move with it) */
            ui.lxt[t] = (int8_t)x;
            ui.trk_done = 1;                     /* (its button held for this: no copy) */
            m[7] = 'T';
            m[8] = (char)('1' + t);
            m[9] = ' ';
            m[10] = 0;
        } else {
            x = clampi(ui.lx + (btn_bit(press, B_OCTUP) ? 1 : -1), -lim, lim);
            for (l = 0; l < NLAYER; l++)
                latch_move(l, x - ui.lx);        /* (every track's latched notes with them) */
            ui.lx = (int8_t)x;
        }
        lx_post();
        if (x > 0)
            str_cpy(m + str_len(m), "+", 2);
        fmt_int(m + str_len(m), x);
        say(m, 1200);
    } else if (btn_bit(press, B_OCTDN) || btn_bit(press, B_OCTUP)) {
        char m[8] = "OCT  ";
        int32_t o = clampi(ui.oct[ui.sel] + (btn_bit(press, B_OCTUP) ? 1 : -1), -3, 3);
        ui.oct[ui.sel] = (int8_t)o;
        ba_register[ui.sel] = (int8_t)o;
        m[4] = o < 0 ? '-' : o > 0 ? '+' : ' ';
        m[5] = (char)('0' + (o < 0 ? -o : o));
        m[6] = 0;
        say(m, 1200);
    }
    s = enc_take(EN_PRESET);
    if (s && rx_page_up()) {                     /* PRESETS on the PLAY ALONG page: REACT, SHADOW, ARPEGGIO */
        rx_mode_set((uint32_t)clampi((int32_t)rx.mode + (s > 0 ? 1 : -1), 0, RXM_N - 1));
        if (rx_focus >= rx_nk())
            rx_focus = 0;
        ui.force = 1;
        s = 0;
    } else if (s && ui.set_page) {               /* PRESETS: through GLOBAL SETUP */
        setup_preset(s);
        s = 0;
    } else if (s && ui.mod_page) {               /* PRESETS: through MOD's entries */
        ui.mod_ix = (uint8_t)clampi((int32_t)ui.mod_ix + s, 0, 2 + (int32_t)NMSLOT - 1);
        ui.mod_touched = -1;
        ui.force = 1;
        s = 0;
    } else if (s && sh) {                        /* SHIFT + PRESETS: the family before or after, a new sound of it (the
                                                  * track's view only) */
        if (!ui.rv_page && !ui.mod_page && !ui.rx_page && !ui.sc_page && !ui.env_page && !(ui.bb_page && bb.on[ui.sel]) && !(ui.bl_page && bl.on[ui.sel]) &&
            !ui.pre_page && !ui.ses_page && !ui.snap_page && !ui.ovd) {
            uint32_t e = ui.engine[ui.sel];
            int32_t n = e == ENG_FM ? FF_N : e == ENG_ANIMA ? AK_N : e == ENG_CAL ? CS_N : e == ENG_RUS ? FRACT_N
                        : e == ENG_DRUID ? DK_N : e == ENG_BAY ? BK_N : e == ENG_OB ? OBK_N : HK_N;
            int32_t k = clampi(cur_kind(ui.sel) + s, 0, n - 1), d = s > 0 ? 1 : -1;
            while (e == ENG_FM && fm_retired(k) && k + d >= 0 && k + d < n)
                k += d;                          /* (FM's GLISSE and RUBBER are WARP's now: stepped over) */
            new_sound_of(k, 0);                  /* (at the first or last: that one again) */
        }
        s = 0;
    } else if (s && ui.snap_page) {              /* PRESETS: the SNAPSHOTS page's frame */
        ui.snap_ix = (uint8_t)clampi((int32_t)ui.snap_ix + s, 0, NSNAP - 1);
        s = 0;
    } else if (s && ui.pre_page == SP_LIST) {           /* PRESETS: through the presets */
        ui.pre_ix = (uint8_t)clampi((int32_t)ui.pre_ix + s, 1, PRE_SLOTS);
        s = 0;
    } else if (s && ui.pre_page == SP_ASK) {
        ui.pre_yes = (uint8_t)(s > 0);
        s = 0;
    } else if (s && ui.ses_page == SP_LIST) {    /* PRESETS: through the sessions */
        ui.ses_ix = (uint8_t)clampi((int32_t)ui.ses_ix + s, 1, SES_SLOTS);   /* every detent a slot */
        s = 0;
    } else if (s && ui.ses_page == SP_ASK) {     /* .. NO (left) or YES (right) */
        ui.ses_yes = (uint8_t)(s > 0);
        s = 0;
    }
    if (s) {
        int32_t e = clampi((int32_t)ui.engine[ui.sel] + (s > 0 ? 1 : -1), 0, NENG - 1);
        if (e != ui.engine[ui.sel]) {
            ui.engine[ui.sel] = (uint8_t)e;
            snd_ready(ui.sel, (uint32_t)e);      /* (its sound measured, the first time: a moment) */
            ev_post(EV_ENGINE, ui.sel, 0, (uint32_t)e);
            mac_apply(ui.sel);
        }
    }
    keys = fm1_in.notes;
    ch = keys ^ ui.keys;
    if (ui.bl_page && bl.on[ui.sel]) {           /* BRICKLAYER's page: the same keys, its own direction and speed */
        uint32_t l = ui.sel;
        if ((ch & keys) >> KEY_REV & 1u || (ch & keys) >> KEY_PEND & 1u || (ch & keys) >> KEY_RAND & 1u) {
            uint32_t want = (ch & keys) >> KEY_REV & 1u ? LD_REV : (ch & keys) >> KEY_PEND & 1u ? LD_PEND : LD_RAND;
            bl.dir[l] = (uint8_t)(bl.dir[l] == want ? LD_FWD : want);
            say(bl.dir[l] == LD_REV ? "REVERSE" : bl.dir[l] == LD_PEND ? "PENDULUM" : bl.dir[l] == LD_RAND ? "RANDOM" : "FORWARD", 1200);
        }
        if ((ch & keys) >> KEY_HALF & 1u || (ch & keys) >> KEY_DOUBLE & 1u) {
            uint32_t want = (ch & keys) >> KEY_HALF & 1u ? LS_HALF : LS_DOUBLE;
            bl.spd[l] = (uint8_t)(bl.spd[l] == want ? LS_NORMAL : want);
            say(bl.spd[l] == LS_HALF ? "HALF SPEED" : bl.spd[l] == LS_DOUBLE ? "DOUBLE SPEED" : "NORMAL SPEED", 1200);
        }
    } else if (((ch & keys) >> KEY_HALF & 1u || (ch & keys) >> KEY_DOUBLE & 1u) && !ui.bb_page && !ui.rv_page && !ui.env_page && !ui.mod_page && !ui.rx_page && !ui.sc_page && !ui.snap_page && !ui.ses_page && !ui.pre_page && !ui.set_page && (ui.speed_page || loop[ui.sel].ntrk)) {
        ui.speed_page = (uint8_t)!ui.speed_page;
        ui.speed_loop = 0;
        ui.dial_until = 0;
        ui.force = 1;
    } else if (loop[ui.sel].play && loop[ui.sel].ntrk) {   /* the chosen track's loops, while they play (stopped or
                                                            * none: the keys do nothing, and say nothing): backwards
                                                            * or PENDULUM (or forwards again); half or double speed */
        const looper_t *p = &loop[ui.sel];
        if ((ch & keys) >> KEY_REV & 1u || (ch & keys) >> KEY_PEND & 1u || (ch & keys) >> KEY_RAND & 1u) {
            uint32_t want = (ch & keys) >> KEY_REV & 1u ? LD_REV : (ch & keys) >> KEY_PEND & 1u ? LD_PEND : LD_RAND;
            want = p->dmode == want ? LD_FWD : want;
            ev_post(EV_LOOP_MODE, ui.sel, 0, want);
            say(want == LD_REV ? "REVERSE" : want == LD_PEND ? "PENDULUM" : want == LD_RAND ? "RANDOM" : "FORWARD", 1200);
        }
        if ((ch & keys) >> KEY_HALF & 1u || (ch & keys) >> KEY_DOUBLE & 1u) {
            uint32_t want = (ch & keys) >> KEY_HALF & 1u ? LS_HALF : LS_DOUBLE;
            want = p->rate == want ? LS_NORMAL : want;
            ev_post(EV_LOOP_MODE, ui.sel, 1, want);
            say(want == LS_HALF ? "HALF SPEED" : want == LS_DOUBLE ? "DOUBLE SPEED" : "NORMAL SPEED", 1200);
        }
    }
    if ((ch & keys) >> KEY_CHORD & 1u) {         /* the chord key: held, chord mode on or off; pressed, the next form */
        ui.cho_down = 1;
        ui.cho_done = 0;
        ui.cho_t0 = fm1_ms;
    }
    if (ui.cho_down && (keys >> KEY_CHORD & 1u) && !ui.cho_done && (uint32_t)(fm1_ms - ui.cho_t0) >= 600u) {
        ui.cho_done = 1;
        ui.chord_on[ui.sel] = (uint8_t)!ui.chord_on[ui.sel];
        say(ui.chord_on[ui.sel] ? "CHORDS" : "CHORDS OFF", 1200);
        ui.force = 1;
    }
    if (ui.cho_down && !(keys >> KEY_CHORD & 1u)) {
        ui.cho_down = 0;
        if (!ui.cho_done) {
            if (ui.chord_on[ui.sel]) {
                ui.chord_form[ui.sel] = (uint8_t)((ui.chord_form[ui.sel] + 1u) % CH_N);
                say(CH_NAME[ui.chord_form[ui.sel]], 1200);
                ui.force = 1;                    /* (its name under CHO) */
            } else
                say("CHORDS OFF", 900);
        }
    }
    if ((ch & keys) >> KEY_ENV & 1u) {
        ui.clock_page=ui.acid_page=0;           /* with SHIFT: BRICKLAYER on (its page up) or off */
        if (((keys >> KEY_SHIFT) & 1u) && !bl.on[ui.sel] && bb.on[ui.sel]) {
            say("NOT ALLOWED", 1200);             /* (one sequencer a track: BALLSY there) */
            ui.env_down = 0;
        } else if ((keys >> KEY_SHIFT) & 1u) {
            bl_toggle(ui.sel);
            ui.bl_page = bl.on[ui.sel];
            if (ui.bl_page)
                ui.kit_page = ui.filter_page = ui.gr_page = ui.speed_page = ui.rv_page = ui.ses_page = ui.snap_page = ui.sc_page = ui.pre_page = ui.set_page = ui.env_page = ui.bb_page = 0;
            say(bl.on[ui.sel] ? "BRICKLAYER" : "BRICKLAYER OFF", 900);
            ui.force = 1;
            ui.env_down = 0;
        } else {
            ui.env_down = 1;
            ui.env_done = 0;
            ui.env_t0 = fm1_ms;
        }
    }
    if (ui.env_down && (keys >> KEY_ENV & 1u) && !ui.env_done && bl.on[ui.sel] &&
        (uint32_t)(fm1_ms - ui.env_t0) >= 600u) {   /* held, BRICKLAYER running: its page up or down */
        ui.env_done = 1;
        ui.bl_page = (uint8_t)!ui.bl_page;
        if (ui.bl_page)
            ui.kit_page = ui.filter_page = ui.gr_page = ui.speed_page = ui.rv_page = ui.ses_page = ui.snap_page = ui.sc_page = ui.pre_page = ui.set_page = ui.env_page = ui.bb_page = 0;
        ui.force = 1;
    }
    if (ui.env_down && !(keys >> KEY_ENV & 1u)) {   /* let go soon: the ENVELOPE page up or down */
        ui.env_down = 0;
        if (!ui.env_done) {
            ui.env_page = (uint8_t)!ui.env_page;
            ui.kit_page = ui.filter_page = ui.gr_page = ui.speed_page = ui.rv_page = ui.ses_page = ui.snap_page = ui.sc_page = ui.pre_page = ui.set_page = ui.bb_page = ui.bl_page = 0;
            ui.force = 1;
        }
    }
    if ((ch & keys) >> KEY_EDIT & 1u) {
        ui.clock_page=ui.acid_page=0;          /* with SHIFT: the chosen track's balls on (their page up) or off */
        if (((keys >> KEY_SHIFT) & 1u) && !bb.on[ui.sel] && bl.on[ui.sel]) {
            say("NOT ALLOWED", 1200);             /* (one sequencer a track: BRICKLAYER there) */
            ui.edit_down = 0;
        } else if ((keys >> KEY_SHIFT) & 1u) {
            bb_toggle(ui.sel);
            ui.bb_page = bb.on[ui.sel];
            if (ui.bb_page)
                ui.kit_page = ui.filter_page = ui.gr_page = ui.speed_page = ui.rv_page = ui.ses_page = ui.snap_page = ui.sc_page = ui.pre_page = ui.set_page = ui.env_page = ui.bl_page = 0;
            say(bb.on[ui.sel] ? "BALLSY" : "BALLSY OFF", 900);
            ui.force = 1;
            ui.edit_down = 0;
        } else {
            ui.edit_down = 1;
            ui.edit_done = 0;
            ui.edit_t0 = fm1_ms;
        }
    }
    if(ui.edit_down && (keys>>KEY_EDIT&1u) && !ui.edit_done && !bb.on[ui.sel] && ui.engine[ui.sel]==ENG_BAY && (uint32_t)(fm1_ms-ui.edit_t0)>=600u) {
        unsigned was=ui.kit_page;ui.edit_done=1;
        ui.filter_page=ui.gr_page=ui.speed_page=ui.rv_page=ui.ses_page=ui.snap_page=ui.sc_page=ui.pre_page=ui.set_page=ui.env_page=ui.bl_page=ui.mod_page=ui.rx_page=0;
        ui.kit_page=(uint8_t)!was;ui.dial_until=0;ui.force=1;
    }
    if (ui.edit_down && (keys >> KEY_EDIT & 1u) && !ui.edit_done && bb.on[ui.sel] &&
        (uint32_t)(fm1_ms - ui.edit_t0) >= 600u) {   /* held, the balls running: their page up or down */
        ui.edit_done = 1;
        ui.bb_page = (uint8_t)!ui.bb_page;
        if (ui.bb_page)
            ui.kit_page = ui.filter_page = ui.gr_page = ui.speed_page = ui.rv_page = ui.ses_page = ui.snap_page = ui.sc_page = ui.pre_page = ui.set_page = ui.env_page = ui.bl_page = 0;
        ui.force = 1;
    }
    if (ui.edit_down && !(keys >> KEY_EDIT & 1u)) {   /* let go soon: EDIT on or off */
        ui.edit_down = 0;
        if (!ui.edit_done) {
            ui.edit = (uint8_t)!ui.edit;
            say(ui.edit ? "EDIT" : "EDIT OFF", 900);
        }
    }
    for (k = KEY_AMB; k <= KEY_EXP; k += KEY_EXP - KEY_AMB)
        if (((ch & keys) >> k & 1u) && k == KEY_AMB && (keys >> KEY_SHIFT) & 1u) {
            scale_draw();                         /* SHIFT + black key 1: a scale and root at random, as at start */
            lx_post();                           /* (the loops moved walk the new scale) */
            ui.sc_peek = 1;                      /* (the SCALE page shown a moment, over any page) */
            ui.sc_peek_until = fm1_ms + 1500u;
        } else if ((ch & keys) >> k & 1u) {       /* a path for the layer chosen: its next sounds lean to it */
            uint32_t pa = k == KEY_AMB ? PATH_AMBIENT : PATH_EXP;
            ui.path[ui.sel] = (uint8_t)(ui.path[ui.sel] == pa ? PATH_OPEN : pa);
            say(ui.path[ui.sel] == PATH_AMBIENT ? "AMBIENT" : ui.path[ui.sel] == PATH_EXP ? "EXPERIMENTAL" : "OPEN", 1200);
        }
    if (ui.snap_page) {                          /* the SNAPSHOTS page: the white keys are the 16 snapshots, no notes */
        for (k = 0; k < NKEY; k++)
            if (((ch & keys) >> k & 1u) && white_ix(k) >= 0 && white_ix(k) < (int32_t)NSNAP) {
                ui.snap_key = (int8_t)white_ix(k);
                ui.snap_t0 = fm1_ms;
                ui.snap_done = 0;
                ui.snap_sh = (uint8_t)((keys >> KEY_SHIFT) & 1u);
                ui.snap_ix = (uint8_t)ui.snap_key;
            }
        if (ui.snap_key >= 0) {
            uint32_t kk, down = 0;
            char n[8];
            for (kk = 0; kk < NKEY; kk++)
                if (white_ix(kk) == ui.snap_key && ((keys >> kk) & 1u))
                    down = 1;
            fmt_int(n, ui.snap_key + 1);
            if (down && !ui.snap_done && (uint32_t)(fm1_ms - ui.snap_t0) >= 800u) {
                ui.snap_done = 1;                /* held: stored, or (SHIFT) emptied */
                if (ui.snap_sh || ((keys >> KEY_SHIFT) & 1u)) {
                    snap_clear((uint32_t)ui.snap_key);
                    flash("EMPTIED", n, C_SNAP);
                } else if (snap_store((uint32_t)ui.snap_key))
                    flash("STORED", n, C_SNAP);
                else
                    flash("FULL", n, C_BAD);   /* (the snapshots' room taken: emptying some makes more) */
                ui.force = 1;
            } else if (!down) {                  /* let go soon: recalled (over the morph time) */
                if (!ui.snap_done && snap_has((uint32_t)ui.snap_key))
                    snap_recall((uint32_t)ui.snap_key, ui.morph);
                ui.snap_key = -1;
            }
        }
    } else if ((ch & keys) >> KEY_SHIFT & 1u) {  /* SHIFT pressed: the keys held latch, on the layer they play */
        for (k = 0; k < NKEY; k++)
            if (((ui.keys & keys) >> k & 1u) && white_ix(k) >= 0 && ui.key_layer[k] != KEY_NONE) {
                uint32_t l = ui.key_layer[k];
                ui.latch[l] |= 1u << k;
                ui.latch_note[l][k] = ui.key_note[k];
                ui.latch_form[l][k] = ui.key_form[k];
                latch_mark(l, ui.key_note[k], ui.key_form[k]);   /* (its voices kept from the overload guard) */
                ui.key_layer[k] = KEY_NONE;     /* (letting go of the key no longer ends it) */
            }
    }
    for (k = 0; ch && k < NKEY; k++) {
        if (!((ch >> k) & 1u))
            continue;
        if (white_ix(k) < 0)
            continue;                            /* the black keys: no notes */
        if (((keys >> k) & 1u) && ui.snap_page) {
            ui.key_layer[k] = KEY_NONE;          /* (the SNAPSHOTS page's: above) */
        } else if (((keys >> k) & 1u) && ui.ovd) {   /* PLAY held: white key w, loop w in or out */
            uint32_t w = (uint32_t)white_ix(k);
            const looper_t *p = &loop[ui.sel];
            ui.key_layer[k] = KEY_NONE;
            if (w < p->ntrk)
                ev_post(EV_LOOP_TRK, ui.sel, w, (p->mute >> w) & 1u);
            ui.force = 1;
        } else if (((keys >> k) & 1u) && ui.bl_page && bl.on[ui.sel] && bl.rec[ui.sel] && ((keys >> KEY_SHIFT) & 1u)) {
            bl_remove(ui.sel, white_ix(k), ui.oct[ui.sel]);   /* BRICKLAYER, entry on: SHIFT + a key takes it out */
            ui.key_layer[k] = KEY_NONE;
            ui.force = 1;
        } else if ((keys >> k) & 1u) {
            /* (moved as the track's loops are -- all of them, and its own -- so what is added fits them) */
            if (ui.bl_page && bl.on[ui.sel] && bl.rec[ui.sel]) {   /* BRICKLAYER, entry on: the key's note added */
                bl_add(ui.sel, white_ix(k), ui.oct[ui.sel]);
                ui.force = 1;
            }
            uint32_t note = ui.engine[ui.sel]==ENG_BAY ? 48u+(uint32_t)white_ix(k) : scale_note(white_ix(k) + ui.lx + ui.lxt[ui.sel], ui.oct[ui.sel]), bit = 1u << k;
            if(ui.engine[ui.sel]==ENG_BAY && !ui.bl_page && !ui.bb_page) {
                if(ui.kit_page){ui.kit_pad=(uint8_t)(white_ix(k)&15);ui.force=1;}
                else say(PULSE_NAME[white_ix(k)&15],500);
            }
            ui.key_layer[k] = KEY_NONE;
            if (ui.latch[ui.sel] & bit) {        /* a latched key: SHIFT held lets go of it; alone, nothing */
                if ((keys >> KEY_SHIFT) & 1u) {
                    ui.latch[ui.sel] &= ~bit;
                    chord_press(ui.sel, ui.latch_note[ui.sel][k], ui.latch_form[ui.sel][k], 0);
                    ui.latch_form[ui.sel][k] = 0;
                }
            } else {
                uint32_t f1 = ui.chord_on[ui.sel] ? ui.chord_form[ui.sel] + 1u : 0u, j;
                if (f1)                          /* (chords: one at a time on a track -- the one before let go) */
                    for (j = 0; j < NKEY; j++)
                        if (j != k && ui.key_layer[j] == ui.sel && ui.key_form[j]) {
                            chord_press(ui.sel, ui.key_note[j], ui.key_form[j], 0);
                            ui.key_layer[j] = KEY_NONE;
                        }
                ui.key_layer[k] = ui.sel;
                ui.key_note[k] = (uint8_t)note;
                ui.key_form[k] = (uint8_t)f1;
                chord_press(ui.sel, note, f1, 1);
            }
        } else if (ui.key_layer[k] != KEY_NONE)
            chord_press(ui.key_layer[k], ui.key_note[k], ui.key_form[k], 0);
    }
    ui.keys = keys;
    midi_take();
}

/* ---------------------------------------------------------------- LEDs --- */
static void led_dim_key(uint32_t id, int on)
{
    uint32_t p, r;
    for (p = 0; p < FM1_NCOL; p++)
        for (r = 1; r < 5u; r++)
            if (FM1_KEYMAP[r][p] == (int8_t)id) {
                if (on)
                    fm1_led_dim[p] |= (uint8_t)(1u << r);
                else
                    fm1_led_dim[p] &= (uint8_t)~(1u << r);
            }
}
static void ui_leds(void)
{
    uint32_t l, k;
    for (l = 0; l < NLAYER; l++) {
        fm1_led_key(PANEL_BTN[LAYER_BTN[l]], clip_from() == (int)l ? (fm1_ms / 250u) & 1u : l == (rx_page_up() && rx.on?rx.guide:ui.sel));   /* (on the
                                                                                                         * clipboard: it blinks) */
        led_dim_key(PANEL_BTN[LAYER_BTN[l]], rx_page_up() ? l != (rx.on?rx.guide:ui.sel) && (rx.mask >> l & 1u) : layer_sounding(l));   /* the others glow
                                                                                     * while they sound; on the PLAY ALONG
                                                                                     * page, while they follow the guide */
    }
    {
        const looper_t *p = &loop[ui.sel];
        if (ui.bl_page && bl.on[ui.sel])         /* (BRICKLAYER's page: REC lit while entry is on) */
            fm1_led_key(PANEL_BTN[B_REC], bl.rec[ui.sel]);
        else
            fm1_led_key(PANEL_BTN[B_REC], p->rec == LR_REC || (p->rec == LR_ARMED && (fm1_ms / 250u) & 1u));
        if (rx.on && !seq_page())              /* (PLAY ALONG on: PLAY flashes with each of the guide's notes) */
            fm1_led_key(PANEL_BTN[B_PLAY], rx.flash && fm1_ms + 1u - rx.flash < 70u);
        else
            fm1_led_key(PANEL_BTN[B_PLAY], seq_page() ? (bl.run[ui.sel] || bb.run[ui.sel]) && (fm1_ms / 250u) & 1u   /* (blinking */
                                                      : p->play && p->ntrk);                               /* as its key) */
    }
    fm1_led_key(PANEL_BTN[B_HOME], (int32_t)(ui.home_until - fm1_ms) > 0);
    fm1_led_key(PANEL_BTN[B_SEQ], ui.acid_page || ui.clock_page || ui.rv_page || ui.mod_page || rx_page_up() || (rx.on && (fm1_ms / 600u) & 1u));   /* (PLAY
                                                                                      * ALONG on, off its page: a slow blink) */
    fm1_led_key(PANEL_BTN[B_SAVE], ui.set_page || ui.ses_page || ui.snap_page);   /* (GLOBAL SETUP, SESSIONS, SNAPSHOTS up) */
    fm1_led_key(PANEL_BTN[B_ARP], ui.sc_page);
    fm1_led_key(PANEL_BTN[B_OCTDN], ui.oct[ui.sel] < 0);
    fm1_led_key(PANEL_BTN[B_OCTUP], ui.oct[ui.sel] > 0);
    for (k = 0; k < NKEY; k++) {
        int32_t w = white_ix(k), n = SCALE_N[ui.scale], d = w + ui.lx + ui.lxt[ui.sel];
        if (ui.snap_page) {                      /* the SNAPSHOTS page: each stored glows; the last lit, the one a morph
                                                  * goes to blinking */
            int stored = w >= 0 && w < (int32_t)NSNAP && snap_has((uint32_t)w);
            led_dim_key(14u + k, stored);
            fm1_led_key(14u + k, stored && (w == snap_morph_target() ? (int)((fm1_ms / 250u) & 1u)
                                                                      : w == snap_current() && snap_morph_target() < 0));
            continue;
        }
        led_dim_key(14u + k, !ui.ovd && w >= 0 && (ui.engine[ui.sel]==ENG_BAY ? w%4==0 : (d % n + n) % n == 0));   /* the scale's root glows (as the loops'
                                                                         * transposition moves it) */
        if (ui.ovd)                              /* PLAY held: the loops that play, lit */
            fm1_led_key(14u + k, w >= 0 && (uint32_t)w < loop[ui.sel].ntrk && !((loop[ui.sel].mute >> w) & 1u));
        else
            fm1_led_key(14u + k, w >= 0 && ((((ui.keys >> k) & 1u) && ui.key_layer[k] == ui.sel) ||
                                            ((ui.latch[ui.sel] >> k) & 1u)));
    }
    fm1_led_key(14u + KEY_SHIFT, (ui.keys >> KEY_SHIFT) & 1u);
    fm1_led_key(14u + KEY_AMB, ui.path[ui.sel] == PATH_AMBIENT);
    fm1_led_key(14u + KEY_EXP, ui.path[ui.sel] == PATH_EXP);
    fm1_led_key(14u + KEY_EDIT, bb.on[ui.sel] ? (fm1_ms / 250u) & 1u : ui.edit);   /* (the balls: it blinks) */
    {   /* the loops' direction and speed: shown only while the chosen track's loops play (PLAY lit) -- lit when
         * on, a glow when off; stopped or none, dark (and they do nothing) */
        const looper_t *lp = &loop[ui.sel];
        int blp = ui.bl_page && bl.on[ui.sel];   /* (BRICKLAYER's page: its own, while it runs) */
        int on = blp || (lp->play && lp->ntrk);
        uint32_t dm = blp ? bl.dir[ui.sel] : lp->dmode, rt = blp ? bl.spd[ui.sel] : lp->rate;
        fm1_led_key(14u + KEY_REV, on && dm == LD_REV);
        fm1_led_key(14u + KEY_PEND, on && dm == LD_PEND);
        fm1_led_key(14u + KEY_RAND, on && dm == LD_RAND);
        fm1_led_key(14u + KEY_HALF, on && rt == LS_HALF);
        fm1_led_key(14u + KEY_DOUBLE, on && rt == LS_DOUBLE);
        led_dim_key(14u + KEY_REV, on);
        led_dim_key(14u + KEY_PEND, on);
        led_dim_key(14u + KEY_RAND, on);
        led_dim_key(14u + KEY_HALF, on);
        led_dim_key(14u + KEY_DOUBLE, on);
    }
    led_dim_key(14u + KEY_AMB, 1);               /* (the others with a function glow while off; SHIFT does not) */
    led_dim_key(14u + KEY_EXP, 1);
    led_dim_key(14u + KEY_EDIT, 1);
    led_dim_key(14u + KEY_CHORD, 1);
    led_dim_key(14u + KEY_ENV, 1);
    fm1_led_key(14u + KEY_ENV, bl.on[ui.sel] ? (fm1_ms / 250u) & 1u : ui.env_page);   /* (BRICKLAYER: it blinks) */
    fm1_led_key(14u + KEY_CHORD, ui.chord_on[ui.sel]);
}

/* -------------------------------------------------------------- screen --- */
#define BAND_A 0                 /* the layer's number */
#define BAND_B 144                /* its engine */
#define BAND_C 176               /* its sound, or a message */
#define BAND_M 202               /* its level: the meter, across */
#define BAND_D 222               /* its pan, across, at the very bottom */
#define C_REC RGB(255, 30, 30)
#define C_SEND ui_color(ui.sel)

/* the battery, top right (0.51, as BIGORNA's build 56): three bars green, two green, one amber, one red when low; a
 * white bolt on a USB host's power (the reading is then the supply's). MELODEE's thresholds; -1 none yet, 4 USB */
static int32_t batt_key(void)
{
    if (!batt_raw)
        return -1;
    if (usb.config && !usb.suspended)
        return 4;
    return batt_raw >= 591 ? 3 : batt_raw >= 561 ? 2 : batt_raw >= 531 ? 1 : 0;
}
static int32_t draw_batt(int32_t x, int32_t y)   /* (right edge x): the octave's right edge */
{
    int32_t k = batt_key(), w = 18, h = 10, x0 = x - w - 3, i;
    uint16_t c = k >= 2 ? C_OK : k == 1 ? RGB(255, 170, 0) : RGB(255, 40, 40);
    if (k < 0)
        return x;
    cv_rect(x0, y, w, 2, C_WHITE);
    cv_rect(x0, y + h - 2, w, 2, C_WHITE);
    cv_rect(x0, y, 2, h, C_WHITE);
    cv_rect(x0 + w - 2, y, 2, h, C_WHITE);
    cv_rect(x0 + w, y + 3, 3, h - 6, C_WHITE);
    if (k == 4) {                                /* (the bolt) */
        cv_rect(x0 + 8, y + 2, 3, 3, C_WHITE);
        cv_rect(x0 + 6, y + 4, 6, 2, C_WHITE);
        cv_rect(x0 + 7, y + 5, 3, 3, C_WHITE);
    } else
        for (i = 0; i < (k ? k : 1); i++)
            cv_rect(x0 + 3 + i * 4, y + 3, 3, 4, c);
    return x0 - 8;
}
static int32_t top_key(void)                     /* (what the top corners show: drawn again when it changes) */
{
    return (ui.oct[ui.sel] + 3) * 100 + (batt_key() + 1) * 10 + (int32_t)(ui.vary_shown ? ui.vary_shown - 1u : loop[ui.sel].vary);
}
#include "living.h"
static void draw_number(void)
{
    char d[3] = {'T', (char)('1' + ui.sel), 0};
    ui.shown_top = top_key();
    CV_AREA(0,0,240,BAND_B,C_BLACK) {
        int32_t x=draw_batt(237,5);
        cv_text(8,3,&FONT_XS,d,ui_color(ui.sel));
        if(ui.oct[ui.sel]) {
            int32_t o=ui.oct[ui.sel];
            char t[3]={o<0?'-':'+',(char)('0'+(o<0?-o:o)),0};
            cv_text(x-text_w(&FONT_XS,t),3,&FONT_XS,t,C_WHITE);
        }
        if(ui.vary_shown ? ui.vary_shown-1u : loop[ui.sel].vary)
            cv_text(8,28,&FONT_XS,"VAR",C_WHITE);
        if(ui.chord_on[ui.sel]) {
            static const char *const AB[CH_N]={"TRI","IN1","IN2","SU2","SU4","OPN","4TH"};
            cv_text(8,51,&FONT_XS,AB[ui.chord_form[ui.sel]%CH_N],C_WHITE);
        }
    }
    draw_living(1);
}
static void draw_engine(void)
{
    cv_begin(240,BAND_C-BAND_B,C_BLACK);
    cv_text_fit(0,&FONT_M,ENG_NAME[ui.engine[ui.sel]],ui_color(ui.sel));
    cv_blit(0,BAND_B);
}
/* the message band's size for s: M, or S if even squeezed M will not fit the width */
static const font_t *band_font(const char *s)
{
    return text_w(&FONT_M, s) - 6 * ((int32_t)str_len(s) - 1) <= 236 ? &FONT_M : &FONT_S;
}
/* message: 0 the sound (layer colour on black), 1 a message (black on white), 2 the looper (white on red),
 * 3 the looper's other flash (red on black) */
static void draw_sound(const char *name, int message)
{
    static const uint16_t BG[4] = {C_BLACK, C_WHITE, RGB(220, 0, 0), C_BLACK};
    uint16_t fg = message == 0 ? ui_color(ui.sel) : message == 1 ? C_BLACK : message == 2 ? C_WHITE : RGB(255, 40, 40);
    const font_t *f = &FONT_XS;
    cv_begin(240, BAND_M-BAND_C, BG[message & 3]);
    cv_text_fit((BAND_M-BAND_C - f->h) / 2, f, name, fg);
    cv_blit(0, BAND_C);
}

/* the meter, across: 228 px for -48 .. +6 dBFS (of a layer's own output, after its level) */
#define METER_X 6
#define METER_LEN 228
static int32_t meter_px_db10(int32_t db10)   /* tenths of a dB -> pixels from the left */
{
    return clampi((db10 + 480) * METER_LEN / 540, 0, METER_LEN);
}
static int32_t meter_px(int32_t peak)
{
    int32_t db10;
    if (peak < 130)
        return 0;                                /* below -48 dB */
    db10 = (int32_t)(((int64_t)(log2_q16((uint32_t)peak) - (15 << 16)) * 602) >> 16) / 10;   /* 20 log10 = 6.02 log2 */
    return meter_px_db10(db10);
}
static void draw_meter(int32_t px)
{
    int32_t lv = ui.level[ui.sel], mark;
    cv_begin(240, BAND_D - BAND_M - 2, C_BLACK);
    cv_rect(METER_X, 6, METER_LEN, 5, RGB(40,40,40));
    if (px)
        cv_rect(METER_X, 6, px, 5, ui_color(ui.sel));
    if (lv) {                                    /* the level the knob sets: a white bar right across */
        mark = METER_X + meter_px_db10((lv - LEVEL_UNITY) * 15 - 150);   /* where -15 dBFS of one layer lands */
        cv_rect(mark - 1, 3, 2, 11, C_WHITE);
    } else
        cv_rect(METER_X, 3, 2, 11, C_REC);   /* off: red at the left */
    cv_blit(0, BAND_M);
    ui.shown_meter = px;
    ui.shown_level = lv;
}
static void draw_pan(void)
{
    int32_t pn = ui.pan[ui.sel], x = 120 + pn * 104 / PAN_MAX;   /* the track: x 16 .. 224 */
    cv_begin(240, 240 - BAND_D, C_BLACK);
    cv_rect(14,8,212,2,C_GREY);
    cv_rect(119,4,2,10,C_GREY);
    cv_rect(x-2,2,4,14,ui_color(ui.sel));
    cv_blit(0, BAND_D);
    ui.shown_pan = pn;
}

/* the REVERB page: a title, then a row a parameter: its name, its value, a bar under them */
#define C_DELAY ui_color(ui.sel)
/* the MOD page (SEQ's third): the chosen track's modulation, an entry at a time (PRESETS): LFO 1, LFO 2, then the
 * slots MOD A .. D. Four rows, KNOB 1 .. 4 each its own; MOD's fourth row shows what the slot does now */
static void mod_knob(uint32_t l, uint32_t ix, uint32_t j, int32_t s)
{
    mod_t *m = &lay_mod[l];
    if (ix < 2u) {
        mlfo_t *f = &m->lfo[ix];
        if (j == 0u)
            f->shape = (uint8_t)clampi(f->shape + s, 0, MS_N - 1);
        else if (j == 1u)
            f->rate = (uint8_t)clampi(f->rate + s, 0, 100);
        else if (j == 2u)
            f->mode = (uint8_t)clampi(f->mode + s, 0, MM_N - 1);
        else
            f->fade = (uint8_t)clampi(f->fade + 2 * s, 0, 100);
    } else {
        mslot_t *q = &m->s[ix - 2u];
        if (j == 0u)
            q->src = (uint8_t)clampi(q->src + s, 0, MSRC_N - 1);
        else if (j == 1u)
            q->dst = (uint8_t)clampi(q->dst + s, 0, MD_N - 1);
        else if (j == 2u)
            q->amt = (int8_t)clampi(q->amt + 2 * s, -100, 100);
        else
            return;
    }
    ui.mod_touched = (int8_t)j;
    ui.mod_touch_until = fm1_ms + 1500u;
    ui.force = 1;
}
/* a row, on two lines (a name and its value side by side do not fit at a readable size: TO, INHARMONIC): the name small
 * and grey with its bar beside it (0 none, 1 from the left, 2 from the middle; v -100 .. 100), the value under it */
static void draw_mod_row(uint32_t j, const char *name, const char *val, int bar, int32_t v, int touched)
{
    uint16_t bg = touched ? C_WHITE : C_BLACK, fg = touched ? C_BLACK : C_WHITE, col = ui_color(ui.sel);
    cv_begin(240, 47, bg);
    cv_text(6, 0, &FONT_XS, name, touched ? C_BLACK : RGB(175, 175, 175));
    if (bar) {
        int32_t x0 = 6 + text_w(&FONT_XS, name) + 12, w0 = 234 - x0, y0 = 6;   /* (after the name) */
        cv_rect(x0, y0, w0, 7, touched ? C_GREY : RGB(60, 60, 60));
        if (bar == 1)
            cv_rect(x0, y0, clampi(v, 0, 100) * w0 / 100, 7, touched ? C_BLACK : col);
        else {
            int32_t c = x0 + w0 / 2, w = clampi(v, -100, 100) * (w0 / 2) / 100;
            cv_rect(w >= 0 ? c : c + w, y0, w >= 0 ? w : -w, 7, touched ? C_BLACK : col);
            cv_rect(c - 1, y0 - 2, 2, 11, touched ? C_BLACK : C_WHITE);
        }
    }
    if (val[0])
        cv_text(6, 47 - FONT_S.h - 1, &FONT_S, val, fg);
    cv_rect(0, 46, 240, 1, RGB(50, 50, 50));
    cv_blit(0, 52 + 47 * j);
}
static void draw_mod_page(void)
{
    uint32_t l = ui.sel, ix = ui.mod_ix;
    int32_t t = (int32_t)(ui.mod_touch_until - fm1_ms) > 0 ? ui.mod_touched : -1;
    const mod_t *m = &lay_mod[l];
    char v[16];
    ui.mod_drawn_at = fm1_ms;
    if (ui.force) {
        char ti[8] = "LFO 1";
        if (ix == 1u)
            ti[4] = '2';
        else if (ix >= 2u) {
            str_cpy(ti, "MOD A", sizeof ti);
            ti[4] = (char)('A' + ix - 2u);
        }
        cv_begin(240, 52, C_BLACK);
        cv_text_c(3, &FONT_L, ti, ui_color(l));   /* (in the track's colour: the chosen track's modulation) */
        cv_blit(0, 0);
    }
    if (ix < 2u) {
        const mlfo_t *f = &m->lfo[ix];
        uint32_t ch = (uint32_t)(((uint64_t)100u * exp2_q16(f->rate * 7189)) >> 16);   /* (0.01 Hz units, x 100) */
        if (!ui.force)
            return;                              /* (an LFO's rows change only with its knobs) */
        draw_mod_row(0, "SHAPE", MS_NAME[f->shape % MS_N], 0, 0, t == 0);
        fmt_fix(v, (int32_t)(ch < 100000u ? ch / 100u : ch / 1000u), ch < 100000u ? 2 : 1);
        str_cpy(v + str_len(v), " HZ", 4);
        draw_mod_row(1, "RATE", v, 1, f->rate, t == 1);
        draw_mod_row(2, "MODE", MM_NAME[f->mode % MM_N], 0, 0, t == 2);
        if (f->fade) {
            fmt_fix(v, f->fade, 1);
            str_cpy(v + str_len(v), " S", 3);
        } else
            str_cpy(v, "OFF", 4);
        draw_mod_row(3, "FADE", v, 1, f->fade, t == 3);
        return;
    }
    {
        const mslot_t *q = &m->s[ix - 2u];
        int32_t now = 0;
        if (ui.force) {
            const char *d = q->dst < 4u ? mac_name(l, q->dst) : MD_NAME[q->dst % MD_N];
            draw_mod_row(0, "FROM", MSRC_NAME[q->src % MSRC_N], 0, 0, t == 0);
            draw_mod_row(1, "TO", d, 0, 0, t == 1);
            fmt_int(v, q->amt);
            if (q->amt > 0) {
                v[0] = '+';
                fmt_int(v + 1, q->amt);
            }
            draw_mod_row(2, "AMOUNT", v, 2, q->amt, t == 2);
        }
        if (q->src && q->amt) {                  /* (what it does now: the source times the amount) */
            int32_t sv = q->src == MSRC_L1 || q->src == MSRC_L2 ? mst[l].val[q->src - MSRC_L1]
                         : q->src == MSRC_VEL ? ((int32_t)mst[l].vel - 127) * 258
                         : q->src == MSRC_KEY ? clampi(((int32_t)mst[l].key - 60) * 683, -Q15, Q15) : mst[l].rnd;
            now = sv * q->amt / Q15;
        }
        draw_mod_row(3, "NOW", "", 2, now, 0);
    }
}

#define C_REACT ui_color(ui.sel)
#define C_SHADOW ui_color(ui.sel)
#define C_ARPEG ui_color(ui.sel)
/* the PLAY ALONG page: the mode's name (in its colour while on, grey while off); the name of the knob turned last
 * (as large as fits whole) and its value, large; then a bar for each knob -- KNOB 1 .. 4 in a row; ARPEGGIO's six
 * in two rows of three (SELECT and ALGORITHM the last two) -- the one turned last black on white */
static int8_t rx_shown[9];
static char rx_shown_msg[16];
static void draw_rx_page(void)
{
    const char *m = (int32_t)(ui.msg_until - fm1_ms) > 0 ? ui.msg : "";   /* (a message a moment: 2 IN, GUIDE TRACK) */
    static const char *const KL[6] = {"K1", "K2", "K3", "K4", "SEL", "ALG"};
    char v[8];
    uint32_t j;
    const font_t *f;
    const int8_t *kv = rx_kv();
    const char *const *kn = rx_kn();
    uint16_t col = ui_color(ui.sel);
    uint32_t nk = rx_nk();
    if (!ui.force && ui.shown_page == 13 && rx_shown[6] == (int8_t)rx_focus && !memcmp(rx_shown, kv, nk) &&
        rx_shown[7] == (int8_t)rx.mode && rx_shown[8] == (int8_t)rx.on && str_eq(rx_shown_msg, m))
        return;
    cv_begin(240, 52, C_BLACK);
    f = text_w(&FONT_L, RXM_NAME[rx.mode]) <= 236 ? &FONT_L : &FONT_M;
    cv_text_c((52 - f->h) / 2, f, RXM_NAME[rx.mode], rx.on ? col : C_GREY);
    cv_blit(0, 0);
    if (m[0]) {                                   /* the message, black on white, over the name */
        cv_begin(240, 48, C_WHITE);
        f = text_w(&FONT_M, m) <= 232 ? &FONT_M : &FONT_S;
        cv_text_c((48 - f->h) / 2, f, m, C_BLACK);
    } else {                                      /* the name: medium if it fits whole, else a size smaller */
        cv_begin(240, 48, C_BLACK);
        f = text_w(&FONT_M, kn[rx_focus]) <= 232 ? &FONT_M : &FONT_S;
        cv_text_c((48 - f->h) / 2, f, kn[rx_focus], C_WHITE);
    }
    cv_blit(0, 52);
    cv_begin(240, 56, C_BLACK);                   /* its value */
    fmt_int(v, kv[rx_focus]);
    cv_text_c(5, &FONT_L, v, col);
    cv_blit(0, 100);
    for (j = 0; j < 2u && nk == 6u; j++) {       /* ARPEGGIO's six: two rows of three, each its knob, a bar under */
        uint32_t k;
        cv_begin(240, 42, C_BLACK);
        for (k = 0; k < 3u; k++) {
            uint32_t i = j * 3u + k;
            int on = i == rx_focus;
            int32_t x = (int32_t)k * 80;
            if (on)
                cv_rect(x + 2, 1, 76, 40, C_WHITE);
            cv_text(x + (80 - text_w(&FONT_S, KL[i])) / 2, 1, &FONT_S, KL[i], on ? C_BLACK : C_WHITE);
            cv_rect(x + 8, 33, 64, 6, on ? C_GREY : RGB(60, 60, 60));   /* (its bar under it, across) */
            cv_rect(x + 8, 33, kv[i] * 64 / 100, 6, on ? C_BLACK : col);
        }
        cv_blit(0, 156 + 42 * j);
    }
    for (j = 0; j < 2u && nk == 4u; j++) {        /* the four: KNOB 1 .. 4, and a bar each */
        uint32_t k;
        cv_begin(240, 42, C_BLACK);
        for (k = 0; k < 4u; k++) {
            int on = k == rx_focus;
            int32_t x = (int32_t)k * 60;
            if (on)
                cv_rect(x + 2, 0, 56, 42, C_WHITE);
            if (!j)
                cv_text(x + (60 - text_w(&FONT_S, KL[k])) / 2, (42 - FONT_S.h) / 2, &FONT_S, KL[k], on ? C_BLACK : C_WHITE);
            else {
                cv_rect(x + 10, 6, 40, 30, on ? C_GREY : RGB(60, 60, 60));
                cv_rect(x + 10, 6 + 30 - kv[k] * 30 / 100, 40, kv[k] * 30 / 100, on ? C_BLACK : col);
            }
        }
        cv_blit(0, 156 + 42 * j);
    }
    memcpy(rx_shown, kv, nk);
    rx_shown[6] = (int8_t)rx_focus;
    rx_shown[7] = (int8_t)rx.mode;
    rx_shown[8] = (int8_t)rx.on;
    str_cpy(rx_shown_msg, m, sizeof rx_shown_msg);
    ui.shown_page = 13;
    ui.force = 0;
}
static void draw_rv_title(void)
{
    cv_begin(240, 52, C_BLACK);
    cv_text_c(3, &FONT_L, ui.fx ? (ui.rv_page==2?"DELAY 2/2":"DELAY 1/2") : (ui.rv_page==2?"REVERB 2/2":"REVERB 1/2"), ui.fx ? C_DELAY : C_SEND);
    cv_blit(0, 0);
}
static void draw_rv_row(uint32_t j, int touched)
{
    char v[20];
    const int8_t *pv = ui.rv_page==2?(ui.fx?fx.dl:fx.rv):(ui.fx?ui.dlp:ui.rvp);
    uint16_t bg = touched ? ui_color(ui.sel) : C_BLACK, fg = touched ? C_BLACK : C_WHITE;
    cv_begin(240, 47, bg);
    {
        static const char *const rn[4]={"TYPE","PREDELAY","DIFFUSION","WIDTH"};
        static const char *const dn[4]={"TYPE","DIVISION","RHYTHM","WIDTH"};
        const char *name = ui.rv_page==2?(ui.fx?dn[j]:rn[j]):(ui.fx ? DL_NAME[j] : RV_NAME[j]);
        const font_t *f = &FONT_S;               /* (one size for every row of both pages: REPEATS 100 fits it) */
        int32_t y = (37 - (int32_t)FONT_S.h) / 2;
        if(ui.rv_page==2 && j==0)str_cpy(v,ui.fx?FX_DTYPE[pv[j]]:FX_RTYPE[pv[j]],sizeof v);
        else if(ui.rv_page==2 && ui.fx && j==1)str_cpy(v,FX_DIV[pv[j]],sizeof v);
        else if(ui.rv_page==2 && ui.fx && j==2)str_cpy(v,FX_RHYTHM[pv[j]],sizeof v);
        else if (ui.rv_page==1 && ui.fx && j == 0u) {                  /* the delay's TIME in seconds, no unit (the font has no
                                                  * lower case): 0.02 .. 0.99, 1.0 .. 2.0 */
            int32_t cs = (dl_ms(pv[0]) + 5) / 10, n;
            if (cs >= 100) {
                cs = (cs + 5) / 10;
                fmt_int(v, cs / 10);
                n = str_len(v);
                v[n] = '.';
                v[n + 1] = (char)('0' + cs % 10);
                v[n + 2] = 0;
            } else {
                str_cpy(v, "0.", 3);
                v[2] = (char)('0' + cs / 10);
                v[3] = (char)('0' + cs % 10);
                v[4] = 0;
            }
        } else
            fmt_int(v, pv[j]);
        cv_text(6, y, f, name, fg);
        cv_text(234 - text_w(f, v), y, f, v, touched ? C_BLACK : ui_color(ui.sel));
    }
    cv_rect(6, 38, 228, 6, touched ? C_GREY : RGB(60, 60, 60));
    cv_rect(6, 38, pv[j] * 228 / 100, 6, touched ? C_BLACK : ui.fx ? C_DELAY : C_SEND);
    cv_blit(0, 52 + 47 * j);
    ui.shown_rvp[j] = pv[j];
}
static void draw_rv_page(void)
{
    uint32_t j;
    int32_t t = (int32_t)(ui.rv_touch_until - fm1_ms) > 0 ? ui.rv_touched : -1;
    if (ui.force || !ui.shown_page) {
        draw_rv_title();
        for (j = 0; j < 4u; j++)
            draw_rv_row(j, (int32_t)j == t);
        ui.shown_page = (uint8_t)(1 + ui.fx * 10);
        ui.shown_touch = (int8_t)t;
        ui.force = 0;
        return;
    }
    for (j = 0; j < 4u; j++)
        if (ui.shown_rvp[j] != (ui.rv_page==2?(ui.fx?fx.dl:fx.rv):(ui.fx?ui.dlp:ui.rvp))[j] || (((int32_t)j == t) != ((int32_t)j == ui.shown_touch)))
            draw_rv_row(j, (int32_t)j == t);
    ui.shown_touch = (int8_t)t;
}

/* the ENVELOPE page: the title; the envelope drawn (the stages' widths by their knobs, the sustain a fixed
 * stretch); A D S R in a square under it, the value just turned black on white. AS DRAWN: the sound's own, in grey */
static void env_text(char *m, uint32_t j, int32_t v)   /* 12MS, 1.2S, 20S, 80% */
{
    int32_t ms = env_ms(j, v);
    if (j == 2u) {
        fmt_int(m, v);
        str_cpy(m + str_len(m), "%", 2);
    } else if (ms < 1000) {
        fmt_int(m, ms);
        str_cpy(m + str_len(m), "MS", 3);
    } else {
        if (ms < 10000)
            fmt_fix(m, ms / 100, 1);
        else
            fmt_int(m, ms / 1000);
        str_cpy(m + str_len(m), "S", 2);
    }
}
static int32_t env_level(const int8_t *v, int32_t x, int32_t w)   /* 0 .. 1000 at column x of w */
{
    int32_t sw = w / 6, rest = w - sw, tot = v[0] + v[1] + v[3] + 24;
    int32_t wa = rest * (v[0] + 8) / tot, wd = rest * (v[1] + 8) / tot, s = v[2] * 10, t, u;
    if (x < wa)
        return x * 1000 / wa;
    x -= wa;
    if (x < wd) {
        u = 1000 - x * 1000 / wd;
        return s + (1000 - s) * (u * u / 1000) / 1000;
    }
    x -= wd;
    if (x < sw)
        return s;
    x -= sw;
    t = w - wa - wd - sw;
    u = t > 0 ? 1000 - clampi(x * 1000 / t, 0, 1000) : 0;
    return s * (u * u / 1000) / 1000;
}
#define ENV_GX 8
#define ENV_GW 224
#define ENV_GT 28                /* the graph's top and its line along the bottom, in its area */
#define ENV_GB 100
static void draw_env_page(void)
{
    const int8_t *v = env_shown();
    uint32_t j, on = ui.env_on[ui.sel][ui.engine[ui.sel]];
    int32_t t = (int32_t)(ui.env_touch_until - fm1_ms) > 0 ? ui.env_touched : -1, x, y, yp = ENV_GB;
    uint16_t col = on ? ui_color(ui.sel) : C_GREY;
    int ch = ui.force || ui.shown_env_on != on || ui.shown_env_touch != t;
    for (j = 0; j < 4u; j++)
        ch |= ui.shown_env[j] != v[j];
    if (!ch)
        return;
    if (ui.force) {
        char d[12] = "ENVELOPE  ";
        d[9] = (char)('1' + ui.sel);
        cv_begin(240, 36, C_BLACK);
        cv_text_c(5, &FONT_S, d, ui_color(ui.sel));
        cv_blit(0, 0);
    }
    CV_AREA(0, 36, 240, 104, C_BLACK) {
        if (!on)
            cv_text_c(2, &FONT_XS, "AS DRAWN", C_GREY);
        cv_rect(ENV_GX, ENV_GB, ENV_GW, 2, RGB(70, 70, 70));
        for (x = 0; x < ENV_GW; x++) {
            y = ENV_GB - env_level(v, x, ENV_GW) * (ENV_GB - ENV_GT) / 1000;
            cv_rect(ENV_GX + x, y, 1, ENV_GB - y, RGB(48, 48, 48));
            cv_rect(ENV_GX + x - 1, y < yp ? y : yp, 3, (y < yp ? yp - y : y - yp) + 3, col);
            yp = y;
        }
    }
    CV_AREA(0, 140, 240, 100, C_BLACK) {
        static const char *const N[4] = {"ATTACK", "DECAY", "SUSTAIN", "RELEASE"};
        for (j = 0; j < 4u; j++) {
            int32_t cx = (int32_t)(j & 1u) * 120, cy = (int32_t)(j >> 1) * 50;
            uint16_t fg = (int32_t)j == t ? C_BLACK : C_WHITE;
            char m[12];
            if ((int32_t)j == t)
                cv_rect(cx + 2, cy + 1, 116, 48, C_WHITE);
            cv_bg_set((int32_t)j == t ? C_WHITE : C_BLACK);
            cv_text(cx + 6, cy + 3, &FONT_XS, N[j], (int32_t)j == t ? C_BLACK : C_GREY);
            env_text(m, j, v[j]);
            cv_text(cx + 6, cy + 23, &FONT_S, m, on ? fg : (int32_t)j == t ? C_BLACK : C_GREY);
            cv_bg_set(C_BLACK);
        }
    }
    for (j = 0; j < 4u; j++)
        ui.shown_env[j] = v[j];
    ui.shown_env_on = (uint8_t)on;
    ui.shown_env_touch = (int8_t)t;
    ui.force = 0;
}

/* the SCALE page: the title; the root, very large; the scale's name, one or two lines. What was just turned
 * is drawn black on white for a moment */
#define C_SCALE ui_color(ui.sel)
static void draw_sc_page(void)
{
    int32_t t = (int32_t)(ui.sc_touch_until - fm1_ms) > 0 ? ui.sc_touched : -1;
    uint16_t bg, fg;
    if (!ui.force && ui.shown_scale == ui.scale && ui.shown_root == ui.root && ui.shown_sc_touch == t)
        return;
    cv_begin(240, 50, C_BLACK);
    cv_text_c(6, &FONT_M, "SCALE", C_SCALE);
    cv_blit(0, 0);
    bg = t == 0 ? C_WHITE : C_BLACK;
    fg = t == 0 ? C_BLACK : C_WHITE;
    CV_AREA(0, 50, 240, 100, bg)
        cv_text_c(4, &FONT_XL, NOTE_NAME[ui.root], fg);
    bg = t == 1 ? C_WHITE : C_BLACK;
    fg = t == 1 ? C_BLACK : C_SCALE;
    CV_AREA(0, 150, 240, 90, bg) {
        if (SCALE_L2[ui.scale][0]) {
            cv_text_fit(4, &FONT_M, SCALE_L1[ui.scale], fg);
            cv_text_fit(46, &FONT_M, SCALE_L2[ui.scale], fg);
        } else
            cv_text_fit(26, &FONT_M, SCALE_L1[ui.scale], fg);
    }
    ui.shown_scale = ui.scale;
    ui.shown_root = ui.root;
    ui.shown_sc_touch = (int8_t)t;
}

/* a layer's knob as a dial over the whole screen, drawn band by band (the canvas holds 112 rows): its name and
 * the layer's number; a dial from 7 o'clock to 5, the way it is turned in the layer's colour, a white pointer;
 * under it what it does. The filter and the granulator are off at 12 o'clock and go either way; the send
 * starts at 7 o'clock */
#define DIAL_CX 120
#define DIAL_CY 124
#define DIAL_R 76
static void dial_dot(int32_t oy, int32_t x, int32_t y, int32_t r, uint16_t c) { cv_rect(x - r, y - r - oy, 2 * r + 1, 2 * r + 1, c); }
/* the point at angle a (a turn = 2^32, 0 at the top, clockwise) and radius r */
static void dial_at(uint32_t a, int32_t r, int32_t *x, int32_t *y)
{
    *x = DIAL_CX + mulq15(r, sin_ph(a));
    *y = DIAL_CY - mulq15(r, sin_ph(a + 0x40000000u));
}
static void flt_label(char *m, int32_t v)
{
    int32_t hz;
    if (!v) {
        str_cpy(m, "OFF", 12);
        return;
    }
    hz = (int32_t)exp2_q16(flt_oct(v) - (16 << 16));
    str_cpy(m, v < 0 ? "LP " : "HP ", 12);
    if (hz < 1000)
        fmt_int(m + 3, hz);
    else
        fmt_fix(m + 3, hz / 100, 1);
    str_cpy(m + str_len(m), hz < 1000 ? " HZ" : " KHZ", 6);
}
static int32_t dial_value(void)
{
    if (ui.dial >= DIAL_MAC)
        return ui.mac[ui.sel][ui.engine[ui.sel]][(ui.dial - DIAL_MAC) & 3u];
    return ui.dial == DIAL_FLT ? ui.flt[ui.sel] : ui.dial == DIAL_GR ? ui.gr[ui.sel] : ui.dial == DIAL_CR ? ui.cr[ui.sel]
           : ui.dial == DIAL_DSEND ? ui.dsend[ui.sel] : ui.dial == DIAL_DIST ? ui.dist[ui.sel] : ui.send[ui.sel];
}
static void draw_dial(void)
{
    static const char *const NAME[6] = {"FILTER  ", "GRAIN  ", "REVERB  ", "CRUSH  ", "DELAY  ", "DISTORTION  "};
    int32_t v = dial_value(), k, from, to;    /* the arc lit, in steps of 3 degrees from 12 o'clock */
    uint32_t av;
    char t[16], m[16];
    uint16_t col = ui_color(ui.sel);
    const font_t *tf;
    if (ui.dial >= DIAL_MAC) {                   /* EDIT's macro: its name for this sound, and the layer */
        str_cpy(t, mac_name(ui.sel, (ui.dial - DIAL_MAC) & 3u), sizeof t - 2);
        str_cpy(t + str_len(t), "  ", 3);
    } else
        str_cpy(t, NAME[ui.dial], sizeof t);
    t[str_len(t) - 1] = (char)('1' + ui.sel);
    tf = text_w(&FONT_M, t) <= 236 ? &FONT_M : &FONT_S;   /* (a long name, SATURATION 1: a size smaller) */
    if (ui.dial == DIAL_SEND || ui.dial == DIAL_DSEND || ui.dial == DIAL_DIST) {   /* 0 .. 100: from 7 o'clock round */
        from = -45;
        to = -45 + v * 90 / 100;
        av = 0xA0000000u + (0xC0000000u / 100u) * (uint32_t)v;   /* -135 degrees, + 270 x v / 100 */
        if (ui.dial == DIAL_DIST) {              /* (the distortion: its amount, OFF at 0) */
            if (v)
                fmt_int(m, v);
            else
                str_cpy(m, "OFF", sizeof m);
        } else {
            str_cpy(m, "SEND ", sizeof m);
            fmt_int(m + 5, v);
        }
    } else {                                     /* -64 .. 64: either way from 12 o'clock */
        from = 0;
        to = v * 45 / FLT_MAX;
        av = (uint32_t)((int32_t)(0x60000000u / FLT_MAX) * v);
        if (ui.dial == DIAL_FLT)
            flt_label(m, v);
        else if (ui.dial >= DIAL_MAC) {          /* +40 %, -25 %, or the sound as it was drawn */
            if (!v)
                str_cpy(m, "AS DRAWN", sizeof m);
            else {
                m[0] = v > 0 ? '+' : '-';
                fmt_int(m + 1, (v < 0 ? -v : v) * 100 / MAC_MAX);
                str_cpy(m + str_len(m), "%", 2);
            }
        } else if (!v)
            str_cpy(m, "OFF", sizeof m);
        else if (ui.dial == DIAL_CR) {           /* BITS 6.5, RATE 2.4K, RATE 300 */
            if (v < 0) {
                str_cpy(m, "BITS ", sizeof m);
                fmt_fix(m + 5, cr_bits10(v), 1);
            } else {
                int32_t hz = cr_hz(v);
                str_cpy(m, "RATE ", sizeof m);
                if (hz < 1000)
                    fmt_int(m + 5, hz);
                else
                    fmt_fix(m + 5, hz / 100, 1);
                if (hz >= 1000)
                    str_cpy(m + str_len(m), "K", 2);   /* (short: RATE 2.6K reads at this size) */
            }
        }
        else {
            str_cpy(m, v < 0 ? "DARK " : "SCATTER ", sizeof m);
            fmt_int(m + str_len(m), (v < 0 ? -v : v) * 100 / FLT_MAX);
        }
    }
    if (to < from) {
        int32_t x_ = to;
        to = from;
        from = x_;
    }
    t[str_len(t)-2]=0;
    CV_AREA(0,0,240,240,C_BLACK) {
        char track[3]={'T',(char)('1'+ui.sel),0};
        cv_text(8,3,&FONT_XS,track,col);
        cv_text_c(20,tf,t,col);
        /* Continuous ribbon, separated inner needle and luminous endpoint. */
        for(k=-135;k<135;k++){
            uint32_t ang=(uint32_t)(k*11930465);
            uint32_t next=ang+11930465u;
            uint16_t c=v && k>=from*3 && k<to*3?col:RGB(40,40,40);
            for(int32_t r=70;r<=73;r++){
                int32_t x,y,xx,yy;
                dial_at(ang,r,&x,&y);dial_at(next,r,&xx,&yy);
                living_line(x,y,xx,yy,c);cv_rect(x,y,2,2,c);
            }
        }
        {int32_t x,y,xx,yy;
         dial_at(av,59,&x,&y);dial_at(av,65,&xx,&yy);living_line(x,y,xx,yy,col);
         dial_at(av,72,&x,&y);cv_rect(x-2,y-2,5,5,C_WHITE);}
        cv_text_c(110,text_fit_font(&FONT_M,m,118),m,v?col:C_GREY);
    }
    ui.shown_dial = (int16_t)(v + ui.dial * 256);
    ui.dial_drawn_at = fm1_ms;
}

/* the whole screen flashing (flash()) for 1.5 s, the colour and black taking turns */
static int all_digits(const char *t)
{
    if (!*t)
        return 0;
    for (; *t; t++)
        if (*t < '0' || *t > '9')
            return 0;
    return 1;
}
static int draw_flash(void)
{
    uint32_t t = fm1_ms - ui.flash_t0, ph = t / 250u, on;
    uint16_t bg, fg;
    if (!ui.flash_on)
        return 0;
    if (t >= 1500u) {
        ui.flash_on = 0;
        ui.force = 1;                              /* back to the screen as it was */
        return 0;
    }
    if (ph == ui.flash_phase)
        return 1;
    ui.flash_phase = (uint8_t)ph;
    on = !(ph & 1u);
    bg = on ? ui.flash_col : C_BLACK;
    fg = on ? C_BLACK : ui.flash_col;
    CV_AREA(0, 0, 240, 100, bg)
        cv_text_c(ui.flash_l2[0] ? 40 : 52, &FONT_L, ui.flash_l1, fg);
    CV_AREA(0, 100, 240, 112, bg) {
        if (all_digits(ui.flash_l2))
            cv_text_c(4, &FONT_XL, ui.flash_l2, fg);
        else
            cv_text_fit(10, &FONT_L, ui.flash_l2, fg);   /* (squeezed a little rather than cut at the edge) */
    }
    cv_begin(240, 28, bg);
    cv_blit(0, 212);
    return 1;
}

/* the SESSIONS page: the title, the session chosen (very large), where it is in the list; the question */
/* the question's answer, in a canvas 76 high: NO | YES, the one chosen in white */
static void draw_noyes(int yes)
{
    cv_frame(6, 10, 108, 60, 3, yes ? C_GREY : C_WHITE);
    cv_frame(126, 10, 108, 60, 3, yes ? C_WHITE : C_GREY);
    if (!yes)
        cv_rect(9, 13, 102, 54, C_WHITE);
    else
        cv_rect(129, 13, 102, 54, C_WHITE);
    cv_bg_set(yes ? C_BLACK : C_WHITE);
    cv_text(60 - text_w(&FONT_M, "NO") / 2, 22, &FONT_M, "NO", yes ? C_GREY : C_BLACK);
    cv_bg_set(yes ? C_WHITE : C_BLACK);
    cv_text(180 - text_w(&FONT_M, "YES") / 2, 22, &FONT_M, "YES", yes ? C_BLACK : C_GREY);
    cv_bg_set(C_BLACK);
}
/* text left-aligned at x (x < 0: centred in the canvas), a size smaller or squeezed a little to fit w */
static void cv_text_in(int32_t x, int32_t w, int32_t band_h, const char *t, uint16_t c)
{
    const font_t *f = &FONT_M;
    int32_t n = (int32_t)str_len(t), sq = 0;
    if (text_w(f, t) - 2 * (n - 1) > w)          /* (a size smaller rather than letters crushed together) */
        f = &FONT_S;
    if (text_w(f, t) > w && n > 1)
        sq = clampi((text_w(f, t) - w + n - 2) / (n - 1), 0, 4);
    if (x < 0)
        x = ((int32_t)cv_w - (text_w(f, t) - sq * (n - 1))) / 2;
    for (; *t; t++) {
        char one[2] = {*t, 0};
        x = cv_text(x, (band_h - f->h) / 2, f, one, c) - sq;
    }
}
static const char *kind_name(uint32_t e, int32_t k)
{
    return e == ENG_FM ? FF_NAME[k % FF_N] : e == ENG_ANIMA ? AK_NAME[k % AK_N] : e == ENG_CAL ? CS_NAME[k % CS_N]
           : e == ENG_RUS ? RK_NAME[k % FRACT_N] : e == ENG_DRUID ? DK_NAME[k % DK_N]
           : e == ENG_BAY ? BK_NAME[k % BK_N] : e == ENG_OB ? OBK_NAME[k % OBK_N] : HK_NAME[k % HK_N];
}
/* engine e's preset in slot: its family's name and its number among that engine's presets of the family, in the
 * order of the slots (BRASS 1, BRASS 2 ..); EMPTY */
static void pre_name(uint32_t e, uint32_t slot, char *b, uint32_t nb)
{
    int32_t k = pre_kind(e, slot), n = 1;
    uint32_t s;
    if (k < 0) {
        str_cpy(b, "EMPTY", nb);
        return;
    }
    if (e == ENG_BAY && slot == 1) { str_cpy(b, "KANAGAWA", nb); return; }
    for (s = 1; s < slot; s++)
        n += pre_kind(e, s) == k;
    str_cpy(b, kind_name(e, k), nb);
    str_cpy(b + str_len(b), " ", nb - str_len(b));
    fmt_int(b + str_len(b), n);
}
/* the PRESETS page: the engine's name over four slots (the page of the one chosen), the chosen one in white; a
 * full slot's number in red with its sound's name and number (BRASS 2), an empty one grey. Or, asked: OVERWRITE?,
 * the slot, NO | YES */
static void draw_pre_page(void)
{
    char t[20], n[8];
    uint32_t j, first = (ui.pre_ix - 1u) / 4u * 4u + 1u;
    int16_t key = (int16_t)(ui.pre_ix * 4 + (ui.pre_page == SP_ASK ? 2 + ui.pre_yes : 0));
    if (!ui.force && ui.shown_pre == key)
        return;
    ui.shown_pre = key;
    if (ui.pre_page == SP_ASK) {
        const font_t *f = band_font("OVERWRITE?");
        cv_begin(240, 52, C_BLACK);
        cv_text_fit((52 - f->h) / 2, f, "OVERWRITE?", C_FULL);
        cv_blit(0, 0);
        n[0] = 'P';
        fmt_int(n + 1, ui.pre_ix);
        CV_AREA(0, 52, 240, 112, C_BLACK)
            cv_text_c(8, &FONT_XL, n + 1, C_FULL);
        CV_AREA(0, 164, 240, 76, C_BLACK)
            draw_noyes(ui.pre_yes);
        return;
    }
    str_cpy(t, ENG_NAME[ui.pre_eng], sizeof t);   /* (the engine alone: "OBRADOR PRESETS" was wider than the screen) */
    cv_begin(240, 52, C_BLACK);
    cv_text_in(-1, 228, 52, t, C_SES);
    cv_blit(0, 0);
    for (j = 0; j < 4u; j++) {
        uint32_t slot = first + j;
        int sel = slot == ui.pre_ix;
        int32_t k = pre_kind(ui.pre_eng, slot);
        uint16_t bg = sel ? C_WHITE : C_BLACK;
        char nm[20];
        pre_name(ui.pre_eng, slot, nm, sizeof nm);
        cv_begin(240, 47, bg);                   /* (47: the rows meet, nothing of the screen before between) */
        fmt_int(n, (int32_t)slot);
        cv_text(6, (47 - (int32_t)FONT_S.h) / 2, &FONT_S, n, k >= 0 ? C_FULL : sel ? C_BLACK : C_GREY);
        {   /* the name, in the largest size it fits whole (182 px: UNDERTOW 12 in the smallest) */
            const font_t *f = text_w(&FONT_M, nm) <= 182 ? &FONT_M : text_w(&FONT_S, nm) <= 182 ? &FONT_S : &FONT_XS;
            cv_text(54, (47 - (int32_t)f->h) / 2, f, nm, sel ? C_BLACK : k >= 0 ? C_WHITE : C_GREY);
        }
        cv_blit(0, 52 + 47 * j);
    }
}

/* PLAY held: the chosen layer's loops, 1 .. 10 as the white keys have them -- in, the layer's colour; out, a grey
 * frame; none yet, nothing */
static void draw_ovd_page(void)
{
    const looper_t *p = &loop[ui.sel];
    int32_t key = p->ntrk | p->mute << 4 | (int32_t)ui.sel << 16;
    uint32_t r, c;
    char t[12] = "LOOPS ";
    if (!ui.force && ui.shown_ovd == key)
        return;
    ui.shown_ovd = key;
    t[6] = (char)('1' + ui.sel);
    t[7] = 0;
    cv_begin(240, 52, C_BLACK);
    cv_text_c((52 - FONT_M.h) / 2, &FONT_M, p->ntrk ? t : "NO LOOPS", ui_color(ui.sel));
    cv_blit(0, 0);
    for (r = 0; r < 2u; r++)
        CV_AREA(0, 52 + 94 * r, 240, 94, C_BLACK)
        for (c = 0; c < 5u; c++) {
            uint32_t k = r * 5u + c;
            int32_t x = 4 + (int32_t)c * 47;
            char n[4];
            const font_t *f = k < 9u ? &FONT_M : &FONT_S;
            if (k >= p->ntrk)
                continue;
            fmt_int(n, (int32_t)k + 1);
            if (!((p->mute >> k) & 1u)) {
                cv_rect(x, 6, 43, 82, ui_color(ui.sel));
                cv_bg_set(ui_color(ui.sel));
                cv_text(x + (43 - text_w(f, n)) / 2, 6 + (82 - f->h) / 2, f, n, C_BLACK);
                cv_bg_set(C_BLACK);
            } else {
                cv_frame(x, 6, 43, 82, 3, C_GREY);
                cv_text(x + (43 - text_w(f, n)) / 2, 6 + (82 - f->h) / 2, f, n, C_GREY);
            }
        }
}

static void draw_ses_page(void)
{
    char n[8];
    int has = ses_has(ui.ses_ix);
    if (!ui.force && ui.shown_ses == (int8_t)ui.ses_page && ui.shown_ses_ix == (int16_t)(ui.ses_page == SP_ASK ? ui.ses_yes : ui.ses_ix))
        return;
    {
        const char *t = ui.ses_page != SP_ASK ? "SESSIONS" : ui.ses_over ? "OVERWRITE?" : "SAVE NEW";
        const font_t *f = band_font(t);
        cv_begin(240, 52, C_BLACK);
        cv_text_fit((52 - f->h) / 2, f, t, ui.ses_page == SP_ASK && ui.ses_over ? C_FULL : C_SES);
        cv_blit(0, 0);
    }
    fmt_int(n, ui.ses_page == SP_ASK ? ui.ses_new : ui.ses_ix);
    CV_AREA(0, 52, 240, 112, C_BLACK)            /* a slot with a session in it: its number in red; empty, grey */
        cv_text_c(8, &FONT_XL, n, ui.ses_page == SP_ASK ? (ui.ses_over ? C_FULL : C_WHITE) : has ? C_FULL : C_GREY);
    CV_AREA(0, 164, 240, 76, C_BLACK) {
        if (ui.ses_page == SP_ASK)
            draw_noyes(ui.ses_yes);
        else if (ui.ses_ix == ses_current())
            cv_text_c(20, &FONT_M, has ? "LOADED" : "CHOSEN", C_OK);
        else if (!has)
            cv_text_c(20, &FONT_M, "EMPTY", C_GREY); /* (a full one: its red number says it) */
    }
    ui.shown_ses = (int8_t)ui.ses_page;
    ui.shown_ses_ix = (int16_t)(ui.ses_page == SP_ASK ? ui.ses_yes : ui.ses_ix);
}

/* the SNAPSHOTS page: 1 .. 16 in four rows of four (as the white keys have them) -- holding a state, filled (the one
 * last stored or recalled in white; the one a morph goes to, white and grey by turns); empty, a grey frame; the one
 * framed (PRESETS, a key) in a white frame */
static void draw_snap_page(void)
{
    uint32_t r, c, used = 0;
    int32_t key, cur = snap_current(), tg = snap_morph_target();
    for (r = 0; r < NSNAP; r++)
        used |= (uint32_t)snap_has(r) << r;
    key = (int32_t)(used ^ (uint32_t)ui.snap_ix << 16 ^ (uint32_t)(cur + 1) << 21 ^
                    (uint32_t)(tg >= 0 ? (tg + 1) * 2 + ((fm1_ms / 250u) & 1u) : 0) << 26);
    if (!ui.force && ui.shown_snap == key)
        return;
    ui.shown_snap = key;
    cv_begin(240, 52, C_BLACK);
    cv_text_fit((52 - band_font("SNAPSHOTS")->h) / 2, band_font("SNAPSHOTS"), "SNAPSHOTS", C_SNAP);
    cv_blit(0, 0);
    for (r = 0; r < 4u; r++)
        CV_AREA(0, 52 + 47 * r, 240, 47, C_BLACK)
        for (c = 0; c < 4u; c++) {
            uint32_t k = r * 4u + c;
            int32_t x = 2 + (int32_t)c * 60;
            char n[4];
            uint16_t fill = (int32_t)k == cur ? C_WHITE : C_SNAP;
            const font_t *nf = k < 9u ? &FONT_M : &FONT_S;   /* (10 .. 16 a size smaller, alike: inside the box) */
            if ((int32_t)k == tg)
                fill = (fm1_ms / 250u) & 1u ? C_WHITE : C_GREY;
            fmt_int(n, (int32_t)k + 1);
            if ((used >> k) & 1u) {
                cv_rect(x + 4, 4, 48, 39, fill);
                cv_bg_set(fill);
                cv_text(x + 4 + (48 - text_w(nf, n)) / 2, 4 + (39 - (int32_t)nf->h) / 2, nf, n, C_BLACK);
                cv_bg_set(C_BLACK);
            } else {
                cv_frame(x + 4, 4, 48, 39, 2, C_GREY);
                cv_text(x + 4 + (48 - text_w(nf, n)) / 2, 4 + (39 - (int32_t)nf->h) / 2, nf, n, C_GREY);
            }
            if (k == ui.snap_ix)
                cv_frame(x, 0, 56, 47, 4, C_WHITE);
        }
}
/* KNOB 1 on the SNAPSHOTS page: the morph time over the page while it turns and 1.5 s after -- MORPH, the time large
 * (4.5, or OFF: at once), SECONDS, a bar of its reach (0 .. 30 s) */
static void draw_morph_dial(void)
{
    char v[8];
    if (!ui.force && ui.shown_morph == ui.morph)
        return;
    ui.shown_morph = ui.morph;
    if (ui.morph)
        fmt_fix(v, ui.morph * 5, 1);
    else
        str_cpy(v, "OFF", sizeof v);
    CV_AREA(0, 0, 240, 50, C_BLACK)
        cv_text_c((50 - FONT_M.h) / 2, &FONT_M, "MORPH", C_SNAP);
    CV_AREA(0, 50, 240, 112, C_BLACK)            /* (FONT_XL has no point, no O or F) */
        cv_text_c((112 - FONT_L.h) / 2, &FONT_L, v, C_WHITE);
    CV_AREA(0, 162, 240, 40, C_BLACK)
        if (ui.morph)
            cv_text_c((40 - FONT_S.h) / 2, &FONT_S, "SECONDS", C_GREY);
    CV_AREA(0, 202, 240, 38, C_BLACK) {
        cv_rect(12, 8, 216, 22, RGB(60, 60, 60));
        cv_rect(12, 8, ui.morph * 216 / MORPH_STEPS, 22, C_SNAP);
    }
}

static void draw_clock_page(void) {
    static const char *const target[3]={"LOOPS","BALLSY","BRICKLAYER"};
    uint32_t l=ui.sel,t=ui.clock_target;
    if(!ui.force && ui.shown_page==19) return;
    CV_AREA(0,0,240,240,C_BLACK) {
        char n[24];
        str_cpy(n,"CLOCK T",sizeof n);fmt_int(n+str_len(n),l+1);
        cv_text_c(8,&FONT_M,n,ui_color(l));
        fmt_int(n,clk.bpm);str_cpy(n+str_len(n)," BPM",sizeof n-str_len(n));
        cv_text_c(48,&FONT_L,n,C_WHITE);

        cv_text_c(123,&FONT_M,target[t],ui_color(l));
        cv_text_c(164,&FONT_M,clk.mode[l][t]?"SYNC":"FREE",C_WHITE);
        cv_text_c(199,&FONT_S,clock_label[clk.div[l][t]],clk.mode[l][t]?ui_color(l):C_GREY);
        if(t==CK_LOOP) {fmt_int(n,clk.bars[l]);str_cpy(n+str_len(n)," BARS  SHIFT+K4",sizeof n-str_len(n));cv_text_c(224,&FONT_XS,n,C_GREY);}
    }
    ui.shown_page=19;ui.force=0;
}
static void ui_draw(void)
{
    cv_dust_off=1; /* clean black during performance; splash keeps its own texture */
    if(ui.acid_page) {
        if(ui.force || ui.shown_page!=20) {
            CV_AREA(0,0,240,240,C_BLACK) {
                static const char *const names[4]={"WAVE","ACCENT","SLIDE MS","DRIVE"};
                static const char *const waves[3]={"PRESET","SAW","SQUARE"};char v[20];
                cv_text_c(6,&FONT_S,"ACID",ui_color(ui.sel));
                for(uint32_t j=0;j<4;j++) {int y=38+j*49;char key[3]={'K',(char)('1'+j),0};
                    cv_text(8,y,&FONT_XS,key,C_GREY);cv_text(38,y,&FONT_XS,names[j],C_WHITE);
                    if(!j)str_cpy(v,waves[acid_edit[ui.sel][0]],sizeof v);else fmt_int(v,acid_edit[ui.sel][j]);
                    cv_text(230-text_w(&FONT_S,v),y+19,&FONT_S,v,ui_color(ui.sel));
                    if(j){int32_t max=j==2?500:100;cv_rect(38,y+29,85,3,RGB(40,40,40));cv_rect(38,y+29,clampi(acid_edit[ui.sel][j]*85/max,0,85),3,ui_color(ui.sel));}}
            } ui.force=0;ui.shown_page=20;
        } return;
    }
    if(ui.clock_page) {draw_clock_page();return;}
    const char *name = sound_name(ui.sel, ui.engine[ui.sel]);
    int msg = (int32_t)(ui.msg_until - fm1_ms) > 0;
    const char *c = msg ? ui.msg : name;
    uint32_t st = loop[ui.sel].rec;
    char lp[12];
    int32_t px;
    if (draw_flash())
        return;
    if (ui.sc_peek && (int32_t)(ui.sc_peek_until - fm1_ms) > 0) {   /* a new scale and root (SHIFT + black key 1) */
        if (ui.shown_page != 3)
            ui.force = 1;
        draw_sc_page();
        ui.shown_page = 3;
        ui.shown_ses = 0;
        ui.force = 0;
        return;
    }
    if (ui.sc_peek) {                            /* (shown: back to the page as it was) */
        ui.sc_peek = 0;
        ui.shown_page = 0xFF;
        ui.force = 1;
    }
    if (ui.set_page) {                           /* GLOBAL SETUP (setup.c) */
        if (ui.shown_page != 10)
            ui.force = 1;
        setup_draw();
        ui.shown_page = 10;
        ui.force = 0;
        return;
    }
    if (rx_page_up()) {                          /* PLAY ALONG (SEQ's fourth page) */
        if (ui.shown_page != 13)
            ui.force = 1;
        draw_rx_page();
        return;
    }
    if (ui.mod_page) {                           /* MOD (SEQ's third page) */
        if (ui.shown_page != 11)
            ui.force = 1;
        if (ui.force || (uint32_t)(fm1_ms - ui.mod_drawn_at) >= 40u)
            draw_mod_page();
        ui.shown_page = 11;
        ui.force = 0;
        return;
    }
    if ((int32_t)(ui.dial_until - fm1_ms) > 0 && !ui.ses_page && !ui.snap_page && !ui.sc_page && !ui.rv_page && !ui.pre_page && !ui.ovd &&
        !ui.env_page && !ui.kit_page && !ui.filter_page && !ui.gr_page) {
        if (ui.shown_page != 4 ||
            (ui.shown_dial != (int16_t)(dial_value() + ui.dial * 256) && (uint32_t)(fm1_ms - ui.dial_drawn_at) >= 40u))
            draw_dial();
        ui.shown_page = 4;
        ui.shown_ses = 0;
        return;
    }
    if(ui.kit_page) {
        if(ui.force || ui.shown_page!=23) {
            ba_kit_t kit;ba_kit_get(&ba_buf[ui.sel][ba_pub[ui.sel]],&kit);unsigned p=ui.kit_pad,n=kit.source[p];char value[24];
            CV_AREA(0,0,240,240,C_BLACK) {
                cv_text_c(8,&FONT_M,"RYUJI KIT",ui_color(ui.sel));
                fmt_int(value,p+1);cv_text(12,42,&FONT_S,"K1 PAD",C_WHITE);cv_text(180,42,&FONT_S,value,ui_color(ui.sel));
                cv_text(12,65,&FONT_S,PULSE_NAME[p],C_WHITE);
                cv_text(12,96,&FONT_XS,"K2 SOURCE",C_WHITE);cv_text(130,96,&FONT_S,PULSE_FAMILY_NAME[PULSE_FAMILY[n]],ui_color(ui.sel));
                cv_text(12,119,&FONT_S,PULSE_LABEL[n],C_WHITE);
                fmt_int(value,kit.tune[p]);cv_text(12,150,&FONT_S,"K3 TUNE",C_WHITE);cv_text(180,150,&FONT_S,value,ui_color(ui.sel));
                cv_text(12,181,&FONT_S,"K4 LOCK",C_WHITE);cv_text(180,181,&FONT_S,kit.locks&(1u<<p)?"ON":"OFF",ui_color(ui.sel));
                cv_text_c(210,&FONT_XS,"HOME: RANDOM / SHIFT: PAD",C_WHITE);
                cv_text_c(225,&FONT_XS,"HOLD EDIT: CLOSE",C_WHITE);
            }
        }
        ui.shown_page=23;ui.force=0;return;
    }
    if (ui.filter_page) {
        static const char *const type[7]={"DJ", "LP 12", "HP 12", "BP 12", "LP 24", "HP 24", "BP 24"};
        if (ui.force || ui.shown_page != 18) {
            CV_AREA(0,0,240,240,C_BLACK) {
                char n[16]; uint32_t l=ui.sel;
                cv_text_c(8,&FONT_M,"FILTER",ui_color(l));
                cv_text(12,57,&FONT_S,"CUTOFF",C_WHITE);
                if (flt_edit[l][0]) {
                    fmt_int(n,(int32_t)exp2_q16(262144+(ui.flt[l]+FLT_MAX)*673861/(2*FLT_MAX)-(16<<16)));
                    str_cpy(n+str_len(n)," HZ",4);
                } else fmt_int(n,ui.flt[l]);
                cv_text(228-text_w(&FONT_XS,n),60,&FONT_XS,n,ui_color(l));
                cv_text(12,103,&FONT_S,"RESONANCE",C_WHITE);
                if (flt_edit[l][1]) fmt_int(n,flt_edit[l][1]-1); else str_cpy(n,"AUTO",sizeof n);
                cv_text(228-text_w(&FONT_XS,n),106,&FONT_XS,n,ui_color(l));
                cv_text(12,149,&FONT_S,"TYPE",C_WHITE);
                cv_text(228-text_w(&FONT_XS,type[(uint32_t)flt_edit[l][0]]),152,&FONT_XS,type[(uint32_t)flt_edit[l][0]],ui_color(l));


            }
        }
        ui.shown_page=18; ui.force=0; return;
    }
    if (ui.gr_page) {
        if (!ui.force && ui.shown_page == 17) return;
        static const char *const label[8] = {"SIZE", "DENSITY", "SCATTER", "FEEDBACK","PITCH","REVERSE","FREEZE","PRISM MIX"};
        CV_AREA(0, 0, 240, 240, C_BLACK) {
            cv_rect(8, 8, 3, 20, ui_color(ui.sel));
            cv_text_c(8, &FONT_M, ui.gr_page==2?"PRISM 2/2":"GRAINS 1/2", C_WHITE);
            for (uint32_t j = 0; j < 4u; j++) {
                int32_t y = 46 + 44 * (int32_t)j, v = ui.gr_page==2?fx.grain[ui.sel][j]:gr_edit[ui.sel][j];
                char n[8]; fmt_int(n, v);
                if(ui.gr_page==2 && j==2)str_cpy(n,v?"ON":"OFF",sizeof n);
                cv_text(12, y + 5, &FONT_S, label[j+(ui.gr_page==2?4:0)], C_WHITE);
                cv_text(228 - text_w(&FONT_M, n), y, &FONT_M, n, ui_color(ui.sel));
                cv_rect(12, y + 29, 216, 1, C_GREY);
                int lo=ui.gr_page==1?-100:j==0?-24:0;
                int hi=ui.gr_page==1?100:j==0?24:j==2?1:100;
                cv_rect(12+(0-lo)*214/(hi-lo), y + 26, 1, 7, C_WHITE);
                cv_rect(12+(v-lo)*214/(hi-lo), y + 26, 2, 7, ui_color(ui.sel));
            }
            cv_text_c(224, &FONT_XS, "SEQ: PAGE 1/2", C_GREY);
        }
        ui.shown_page = 17; ui.force = 0;
        return;
    }
    if (ui.speed_page) {
        uint32_t l = ui.sel, k = ui.speed_loop;
        char v[24];
        uint32_t pct = loop_pct(loop[l].speed_pct);
        if (loop[l].rate == LS_HALF) pct /= 2u;
        else if (loop[l].rate == LS_DOUBLE) pct *= 2u;
        CV_AREA(0, 0, 240, 240, C_BLACK) {
        cv_text_c(8, &FONT_M, "LOOP SPEED", C_WHITE);
        cv_text_c(48, &FONT_S, "TRACK", ui_color(l));
        fmt_int(v, (int32_t)pct); str_cpy(v + str_len(v), "%", 2);
        cv_text_c(70, &FONT_L, v, C_WHITE);
        str_cpy(v, "LOOP ", sizeof v); fmt_int(v + 5, loop[l].ntrk ? (int32_t)k + 1 : 0);
        cv_text_c(124, &FONT_S, v, ui_color(l));
        if (k < loop[l].ntrk) { fmt_int(v, (int32_t)loop_pct(loop[l].trk[k].speed_pct)); str_cpy(v + str_len(v), "%", 2); }
        else str_cpy(v, "EMPTY", sizeof v);
        cv_text_c(146, &FONT_L, v, C_WHITE);

        }
        ui.shown_page = 16; ui.force = 0;
        return;
    }
    if (ui.ovd) {
        if (ui.shown_page != 6)
            ui.force = 1;
        draw_ovd_page();
        ui.shown_page = 6;
        ui.force = 0;
        return;
    }
    if (ui.pre_page) {
        if (ui.shown_page != 5)
            ui.force = 1;
        draw_pre_page();
        ui.shown_page = 5;
        ui.force = 0;
        return;
    }
    if (ui.snap_page && (int32_t)(ui.morph_until - fm1_ms) > 0) {   /* (KNOB 1 turning there: the morph time) */
        if (ui.shown_page != 15)
            ui.force = 1;
        draw_morph_dial();
        ui.shown_page = 15;
        ui.force = 0;
        return;
    }
    if (ui.snap_page) {
        if (ui.shown_page != 14)
            ui.force = 1;
        draw_snap_page();
        ui.shown_page = 14;
        ui.force = 0;
        return;
    }
    if (ui.ses_page) {
        draw_ses_page();
        ui.shown_page = 2;
        ui.force = 0;
        return;
    }
    ui.shown_ses = 0;
    if (ui.sc_page) {
        if (ui.shown_page != 3)
            ui.force = 1;
        draw_sc_page();
        ui.shown_page = 3;
        ui.force = 0;
        return;
    }
    if (ui.env_page) {
        if (ui.shown_page != 7)
            ui.force = 1;
        draw_env_page();
        ui.shown_page = 7;
        return;
    }
    if (ui.bl_page && bl.on[ui.sel]) {           /* BRICKLAYER, at ~25 frames a second */
        if (ui.shown_page != 9 || ui.force || (uint32_t)(fm1_ms - bl.drawn_at) >= 40u)
            draw_bl_page();
        ui.shown_page = 9;
        ui.force = 0;
        return;
    }
    if (ui.bb_page && bb.on[ui.sel]) {           /* the chosen track's balls, at ~25 frames a second */
        if (ui.shown_page != 8 || ui.force || (uint32_t)(fm1_ms - bb.drawn_at) >= 40u)
            draw_bb_page();
        ui.shown_page = 8;
        ui.force = 0;
        return;
    }
    if (ui.rv_page) {
        if (ui.shown_page != 1 + ui.fx * 10)
            ui.force = 1;                        /* from another page or the dial: all of it */
        draw_rv_page();
        return;
    }
    if (ui.shown_page) {                         /* back from a page: everything again */
        ui.shown_page = 0;
        ui.force = 1;
    }
    if (!msg && st != LR_IDLE) {                 /* the looper over the sound: red, unmissable; REC 3 */
        str_cpy(lp, st == LR_REC ? "REC " : "ARMED ", sizeof lp);
        fmt_int(lp + str_len(lp), loop[ui.sel].ntrk + 1);
        c = lp;
        msg = st == LR_REC ? 2 : (fm1_ms / 250u) & 1u ? 2 : 3;
    }
    if (ui.force || ui.shown_sel != ui.sel || ui.shown_eng != ui.engine[ui.sel] || ui.shown_top != top_key()) {
        draw_number();
        ui.shown_sel = ui.sel;
        ui.shown_eng = ui.shown_msg = ui.shown_pan = ui.shown_level = -100;   /* the rest follows the layer */
    }
    if (ui.shown_eng != ui.engine[ui.sel]) {
        draw_engine();
        ui.shown_eng = ui.engine[ui.sel];
        ui.shown_msg = -1;
    }
    if (ui.shown_msg != msg || !str_eq(c, ui.shown_text)) {
        draw_sound(c, msg);
        str_cpy(ui.shown_text, c, sizeof ui.shown_text);
        ui.shown_msg = msg;
    }
    draw_living(ui.force);
    px = meter_px(lay[ui.sel].meter);
    if (ui.shown_level != ui.level[ui.sel] || ((uint32_t)(fm1_ms - ui.meter_at) >= 30u && px != ui.shown_meter)) {
        draw_meter(px);
        ui.meter_at = fm1_ms;
    }
    if (ui.shown_pan != ui.pan[ui.sel])
        draw_pan();
    ui.force = 0;
}

static void ui_init(void)
{
    uint32_t l;
    memset(&ui, 0, sizeof ui);
    for (l = 0; l < NLAYER; l++) {
        ui.engine[l] = lay[l].engine;
        ui.level[l] = LEVEL_UNITY;
        ui.pan[l] = PAN_DEF[l];
        ui.send[l] = SEND_DEF;
        level_pan_apply(l);
    }
    for (l = 0; l < 4u; l++)
        ui.rvp[l] = RV_DEF[l];
    rv_param(ui.rvp[0], ui.rvp[1], ui.rvp[2], ui.rvp[3]);
    for (l = 0; l < 4u; l++)
        ui.dlp[l] = DL_DEF[l];
    dl_param(ui.dlp[0], ui.dlp[1], ui.dlp[2], ui.dlp[3]);
    ui.rv_touched = -1;
    memset(&bb, 0, sizeof bb);
    for (l = 0; l < NLAYER; l++)
        bb_defaults(l);
    memset(&bl, 0, sizeof bl);
    for (l = 0; l < NLAYER; l++)
        bl_defaults(l);
    bl.touched = -1;
    bb.touched = -1;
    ui.shown_sel = ui.shown_eng = ui.shown_msg = -1;
#if TELEMETRY
    ui.seed = 0x5EEDu;
#else
    ui.seed = fm1_ticks() ^ 0x5EEDu;
#endif
    ui.force = 1;
}

/* the sounds every layer starts with: one of each engine -- measured only the one it plays (the others when it
 * comes to them: snd_ready) */
static void sounds_init(void)
{
    uint32_t l;
    for (l = 0; l < NLAYER; l++) {
        uint32_t s = next_seed();
        fm_generate(&fm_buf[l][0], -1, s, PATH_OPEN, GEN_NOW);
        an_design(&an_buf[l][0], -1, s * 7u + 3u, PATH_OPEN, GEN_NOW);
        cal_design(&cal_buf[l][0], -1, s * 13u + 5u, PATH_OPEN, GEN_NOW);
        rus_design(&rus_buf[l][0], -1, s * 17u + 9u, PATH_OPEN, GEN_NOW);
        dr_design(&dr_buf[l][0], -1, s * 19u + 11u, PATH_OPEN, GEN_NOW);
        ba_design(&ba_buf[l][0], 6+(int32_t)(l&1u), s * 23u + 13u, PATH_OPEN, GEN_NOW);
        hv_design(&hv_buf[l][0], -1, s * 29u + 17u, PATH_OPEN, GEN_NOW);
        ob_design(&ob_buf[l][0], -1, s * 31u + 19u, PATH_OPEN, GEN_NOW);
        fm_pub[l] = fm_use[l] = an_pub[l] = an_use[l] = ob_pub[l] = ob_use[l] = 0;
        cal_pub[l] = cal_use[l] = rus_pub[l] = rus_use[l] = dr_pub[l] = dr_use[l] = ba_pub[l] = ba_use[l] = hv_pub[l] = hv_use[l] = 0;
        snd_raw[l] = (uint8_t)((1u << NENG) - 1u);   /* (none measured yet:) */
        snd_measure(l, ui.engine[l], 0);         /* the one it plays (before the audio starts) */
        gran_profile(l, next_seed());            /* the granulator's character, drawn */
    }
}
