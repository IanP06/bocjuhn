```
=-=-=-=-=-=-=-=-=-=-=
   Michael Fischer

         of

T E C H N O P O L I S
=-=-=-=-=-=-=-=-=-=-=

      Presents...

Roland TR-808 Rhythm Composer
Sound Sample Set 1.0.0 (09/08/94)

The Roland TR-808 (popularly known as the "808") is, perhaps, the most
popular analogue electronic drum machine of all time.  Since its debut
in 1982, it has been the drum machine used the most by dance, pop, rap,
and rhythm and blues artists to produce the drum rhythm tracks for their
songs.  (The famous cowbell sound at the beginning of Whitney Houston's
"I Wanna' Dance with Somebody", or the famous bass drum sound that
vibrates the ground when a car playing loud rap music drives by) Without
a doubt, the Roland TR-808 Rhythm Composer is a "classic beat box".

In recent years, many electronic musical instrument companies (Roland
and many others...) and studio engineer types have attempted to capture
its timeless sound through the use of sampling.  This has however,
proven to be an often disappointing endeavour, due the the analogue
nature of the "808".  Because the "808" is a truly "analogue" drum
machine, with very many (22 to be exact) knobs for the settings for its
drum sounds, sampling the unit often yields sample sets which are too
discrete (i.e. too "static" and too "limited" in variation) and simply
do not do justice to the wide sound range the "808" can produce.  As a
result, people still, to this day, are in hot pursuit of real "808"'s,
and its U.S. dollar resale value today ($250 - $1,000) is often not too
far off from its U.S. dollar retail price at its introduction more than
a decade ago ($1,000).

I sincerely believe I have made major progress in narrowing the
difference between owning a real "808" and owning samples of one.  When
put to proper use, these samples can be considered better than using a
real "808".  Unlike a real "808", with these samples one can have the
certain drum sounds playing simultaneously that cannot do so on a real
"808", (Hand Claps and Maracas, for example.) as well as scale the
velocities of the sounds, and even apply grooves and timing to the beat
in a manner much more sophisticated and clearly beyond the capabilities
of a real "808".  With the right sampler, these "808" samples can, for
all practical purposes, make a real "808" obsolete. I feel these samples
are of higher quality than those found in current commercial drum
machines.  I feel these "808" samples are of higher quality than any
currently offered by commercial sample vendors.  Quite frankly, I feel
this is the best overall sound sample set of the TR-808 to date. And
best of all, and very unlike many of the "competiting" samples, these
samples are ABSOLUTELY FREE!

What I have attempted to do is create a high quality sound sample set of
the "808" that is so comprehensive in sample range, that even the
"analogue purist" (the types who are actively pursing real "808"'s still
today...) would be satisfied.  I have, through very time consuming,
painstaking sampling and sample editing work, using professional grade
equipment, sampled the "808" at five (see "FILENAME INFO" near the end
of this text file...) uniformly spaced positions for each sound modifier
knob. ("LEVEL" being the only exception---as I always kept "LEVEL" at
full to maintain the best signal to noise ratio.)  As a result, this
rather comprehensive "808" sound sample set has the following :

25 Bass Drum sounds
25 Snare Drum sounds
5 Low Tom sounds
5 Mid Tom sounds
5 Hi Tom sounds
5 Low Conga sounds
5 Mid Conga sounds
5 Hi Conga sounds
1 Rim Shot sound
1 Claves sound
1 Hand Clap sound
1 Maracas sound
1 Cow Bell sound
25 Cymbal sounds
5 Open Hi Hat sounds
1 Closed Hi Hat sound

...making for a grand total of 116 sound samples of the Roland TR-808
Rhythm Composer!

These samples were taken _DIRECTLY_ from a Roland TR-808 Rhythm Composer
(SERIAL NO. 103852).  They are _NOT_ samples of samples (i.e. sampled
from a recent drum machine, such as the Boss DR-660, Roland R-8,
R-8MkII, etc...)  In other words, these samples were taken from a REAL
TR-808.  All samples were recorded from the individual sound outputs (I
did NOT use the "HI" or "LO" "LEVEL" "MASTER OUT"puts!).  While being
recorded, each sound (on the TR-808) was at highest volume level (with
all other volume levels set to the lowest possible setting), and the
master volume (on the TR-808) was always at the lowest setting.  All
samples were made using SoundEdit 16 1.0.0 on a Macintosh Quadra 660AV.

EACH and EVERY sample is at 16-Bit, 44.1kHz resolution and was CAREFULLY
generated, sampled, selected (I recorded many hits of the same
sound, and picked the one that I felt best represented the average of
that particular sound) and edited.

Please enjoy this timeless sample set, and feel free to send me your
comments (positive or negative).

Most Sincerely,

Michael Fischer
Technopolis
(810) 650-6396
fischer1@student.msu.edu

=-=-=-=-=-=-=
FILENAME INFO
=-=-=-=-=-=-=

Bass Drum sounds start with "BD".
Snare Drum sounds start with "SD".
Low Tom sounds start with "LT".
Mid Tom sounds start with "MT".
Hi Tom sounds start with "HT".
Low Conga sounds start with "LC".
Mid Conga sounds start with "MC".
Hi Conga sounds start with "HC".
Rim Shot sound starts with "RS".
Claves sounds starts with "CL".
Hand Clap sound starts with "CP".
Maracas sound starts with "MA".
Cowbell sound starts with "CB".
Cymbal sounds start with "CY".
Open Hi Hat sounds start with "OH".
Closed Hi Hat sound starts with "CH".

These two letter abbreviations which determine what the filename begins
with are the exact ones used to abbreviate the sound names on the actual
TR-808 instrument select dial.

The "LEVEL" knob does not count as a knob in filenames, as it
was always at the maximum setting (to maintain the highest signal to
noise ratio.)

On the TR-808, each knob involved in the
composition/generation/synthesis of a particular drum sound has 11
uniformly spaced position marks on it (the positions on the dials are
not numbered, however...and hopefully the synthesis variable they
control is linearly distributed with respect to the knob position!)    I
consider these 11 marks to be "0" through "10".  Due to the fact that
the "0" position and the "10" position are the minimum (most
counter-clockwise) and maximum (most clockwise) positions, one may
consider "0" to be the minimum setting and "10" to be the maximum
setting.  I decided to use dial positions "0" (minimum), "2.5", "5.0"
(middle), "7.5" and "10.0" (maximum) for my samples.  As a result, I
decided upon the following naming convention :

"<filename>00.<file extension>" would be a file whose first (and only,
in this case) knob was set to 0.0 (or the minimum position).

"<filename>25.<file extension>" would be a file whose first (and only,
in this case) knob was set to 2.5.

"<filename>50.<file extension>" would be a file whose first (and only,
in this case) knob was set to 5.0 (or the middle position).

"<filename>75.<file extension>" would be a file whose first (and only,
in this case) knob was set to 7.5.

"<filename>10.<file extension>" would be a file whose first (and only,
in this case) knob was set to 10.0 (or the maximum position).  It does
NOT mean the knob was set to 1.0!

Example : Low Tom with "TUNING" knob set to middle position would be
"LT50.<file extension>".  If the file happened to be a ".WAV" ("WAVE")
file, the name would be "LT50.WAV".

For sounds which had TWO knobs, such as the Bass Drum, Snare Drum, and
Cymbal...

The naming convention is the same, but with two additional setting
position numbers after the first two...

Example : Bass Drum with "TUNING" knob set between the minimum and
middle position and "DECAY" set halfway between the middle and maximum
position would be "BD2575.<file extension>".  If the file happened to be
a ".WAV" ("WAVE") file, the name would be "BD2575.WAV".

Once again, this naming convention was used for ALL the samples.

Of importance is the following :

* In filenames, "TONE" and "TUNING" come before "DECAY" and "SNAPPY".

Once again, please enjoy, and please do send me feedback on what you
think of these samples.

Sincerely,

Michael Fischer
Technopolis
(810) 650-6396
fischer1@student.msu.edu
```
